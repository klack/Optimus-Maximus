#ifndef MX_USB_DEVICE_ENUMERATOR
#define MX_USB_DEVICE_ENUMERATOR

#include "MaximusDefaults.h"

#include <vector>
#include <atlstr.h>

//#include <cfgmgr32.h> - required for DEVINST, but cfg.h in not present in VS2003

class MXDeviceEnumerator
{
public:
	struct DeviceInfo
	{
		typedef std::vector<DeviceInfo> vector_t;

		TCHAR        VDriveLetter;
		CAtlString VDriveDevicePath;
		CAtlString VDriveVolumeName;
		CAtlString MultimediaHidEndpointDevicePath;
		CAtlString InternalHidEndpointDevicePath;

		DeviceInfo():VDriveLetter(_T('\0')){}

		bool isComplete() const;
	};

public:
	MXDeviceEnumerator();
	~MXDeviceEnumerator();

public:
	DeviceInfo::vector_t EnumerateMaximuses();

private:
	void EnumerateDeviceTree(size_t level, DWORD device_inst, DeviceInfo& device_info, bool);
	bool ProcessDevice(TCHAR*, DWORD device_inst, DeviceInfo& device_info, bool);

	static TCHAR VolumeName2DriveLetter(LPCTSTR volume_name);
	static CAtlString getVolumeName(const CAtlString& device_path);
	static CAtlString getDevicePath(LPCTSTR device_id, GUID interface_guid, DWORD device_inst);
};

#endif //MX_USB_DEVICE_ENUMERATOR