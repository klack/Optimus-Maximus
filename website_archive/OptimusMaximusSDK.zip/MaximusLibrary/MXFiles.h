#ifndef MX_FILES_H
#define MX_FILES_H

#include "MaximusDefaults.h"

#include <atlstr.h>
#include <atlsync.h>

class MXBinaryFile
{
public:
	bool Open(LPCTSTR, DWORD dwDesiredAccess = FILE_WRITE_DATA);
	bool WriteData(LPCVOID data, DWORD data_size);
	bool ReadData(LPVOID data, DWORD data_size);
	void Close() {m_Handle.Close();}

	bool IsOpened() const {return m_Handle != NULL;}

private:
	ATL::CHandle m_Handle;
};

class MXNamedFile : public MXBinaryFile
{
public:
	const CAtlString& GetFileName() const {return m_FileName;}
	void SetFile(LPCWSTR file_name){m_FileName = file_name;}

protected:
	CAtlString m_FileName;
};

class MXAsynchronousWriteFile : public MXNamedFile
{
public:
	typedef MXNamedFile base_t;

public:
	MXAsynchronousWriteFile(){Reset();}

public:
	bool WriteData(LPCVOID data, DWORD data_size);
	bool FlushBuffer();
	void Close();

	void SetBuffer(BYTE* buffer, BYTE* buffer2, DWORD buffer_size){m_pBuffer = buffer; m_pBuffer2 = buffer2; m_BufferSize = buffer_size;}

private:
	void Reset();
	bool Open();

private:	
	ATL::CCriticalSection m_Lock;

	BYTE* m_pBuffer;
	BYTE* m_pBuffer2;
	DWORD m_BufferSize;	

	bool m_Fresh;
};

class MXReadFile : public MXNamedFile
{
public:
	typedef MXNamedFile base_t;

public:
	MXReadFile(){Reset();}

public:
	BYTE* ReadData();
	void  Close();

	void SetBuffer(BYTE* buffer, DWORD buffer_size){m_pBuffer = buffer; m_BufferSize = buffer_size;}

private:
	void Reset();

private:
	BYTE* m_pBuffer;
	DWORD m_BufferSize;	
};

#endif //MX_FILES_H
