#include "StdAfx.h"

#include "MXDeviceEnumerator.h"

#include <vector>

#include <cfgmgr32.h>

DEFINE_GUID(GUID_DEVINTERFACE_VOLUME, 0x53f5630dL, 0xb6bf, 0x11d0, 0x94, 0xf2, 0x00, 0xa0, 0xc9, 0x1e, 0xfb, 0x8b);

extern "C"
{
#include "Setupapi.h"
}

#pragma comment(lib, "Setupapi.lib")

const TCHAR* g_HubVidPid = _T("USB\\VID_05E3&PID_0608");
const TCHAR* g_VDriveEndpoint[] = {_T("USBSTOR\\DISK&VEN_LEBEDEV&PROD_OM113_V.DISK"), 
								   _T("USBSTOR\\DISK&VEN_NXP_SEMI&PROD_LPC288X"),
								   _T("USBSTOR\\DISK&VEN_ALS&PROD_MAXIMUS_DISK"),
								   _T("USBSTOR\\DISK&VEN_MAXIMUS&PROD_DISK")}; 
const TCHAR* g_MultimediaHidEndpoint = _T("HID\\VID_04D9&PID_0022&MI_01&COL01");
const TCHAR* g_InternalHidEndpoint = _T("HID\\VID_8123&PID_1457&MI_01");

inline bool isMultimediaHidEndpoint(const CAtlString& device_id)
{
	return device_id.Find(g_MultimediaHidEndpoint) >= 0;
}

inline bool isInternalHidEndpoint(const CAtlString& device_id)
{
	return device_id.Find(g_InternalHidEndpoint) >= 0;
}

inline bool isMaximsDriveDevice(const CAtlString& device_id)
{
	bool res = false;

	for (size_t ii = 0; ii < sizeof(g_VDriveEndpoint)/sizeof(const TCHAR*); ++ii)
	{
		if (device_id.Find(g_VDriveEndpoint[ii]) >= 0)
		{
			res = true;
			break;
		}
	}

	return res;
}

inline bool isHubEndpoint(const CAtlString& device_id)
{
	return device_id.Find(g_HubVidPid) >= 0;
}

bool MXDeviceEnumerator::DeviceInfo::isComplete() const
{
	return !MultimediaHidEndpointDevicePath.IsEmpty() && !VDriveVolumeName.IsEmpty();
}

MXDeviceEnumerator::MXDeviceEnumerator()
{
}

MXDeviceEnumerator::~MXDeviceEnumerator()
{
}

TCHAR MXDeviceEnumerator::VolumeName2DriveLetter(LPCTSTR volume_name)
{
	TCHAR res = _T('\0');

	TCHAR drive[] = _T("A:\\");
	TCHAR curr_volume[MAX_PATH];        

	DWORD mask = ::GetLogicalDrives();

	for (; drive[0]<='Z'; drive[0]++)
	{
		if ((mask & 1) 
			&& ::GetDriveType(drive) == DRIVE_REMOVABLE
			&& ::GetVolumeNameForVolumeMountPoint(drive, curr_volume, sizeof(curr_volume)/sizeof(TCHAR))
			&& _tcscmp(curr_volume, volume_name) == 0)
		{
			res = drive[0];
			break;
		}

		mask >>= 1;
	}

	return res;
}

CAtlString MXDeviceEnumerator::getVolumeName(const CAtlString& device_path)
{
	TCHAR volume_name[MAX_PATH] = {0};

	if (!device_path.IsEmpty())
	{
		::GetVolumeNameForVolumeMountPoint(device_path + _T('\\'), volume_name, sizeof(volume_name)/sizeof(TCHAR));
	}

	return volume_name;
}

CAtlString DeviceEnumFunc(HDEVINFO hDevsInfo, SP_DEVICE_INTERFACE_DATA& deviface_data, DEVINST device_inst, LPCWSTR dev_id)
{
	CAtlString res;

	CAtlString formated_dev_id(dev_id);
	formated_dev_id.MakeLower();
	formated_dev_id.Replace(_T('\\'), _T('#'));

	DWORD buffer_size = 0;
	SP_DEVINFO_DATA devinfo_data = {0};
	devinfo_data.cbSize = sizeof(devinfo_data);

	::SetupDiGetDeviceInterfaceDetail(hDevsInfo, &deviface_data, NULL, 0, &buffer_size, &devinfo_data);
	if (buffer_size != 0 && ::GetLastError() == ERROR_INSUFFICIENT_BUFFER)
	{
		std::vector<char> buffer(buffer_size); 
		SP_DEVICE_INTERFACE_DETAIL_DATA* pDetailData = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA*>(&buffer.front());
		pDetailData->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

		if (::SetupDiGetDeviceInterfaceDetail(hDevsInfo, &deviface_data, pDetailData, buffer_size, &buffer_size, &devinfo_data))
		{
			if (_tcsstr(pDetailData->DevicePath, formated_dev_id))
			{
				res = pDetailData->DevicePath;
			}
		}
	}

	return res;
}

CAtlString MXDeviceEnumerator::getDevicePath(LPCTSTR device_id, GUID interface_guid, DEVINST device_inst)
{
	TCHAR device_path[MAX_PATH] = {0};

	::CM_Get_Device_Interface_List((LPGUID)&interface_guid, (LPTSTR)device_id, device_path, MAX_PATH, CM_GET_DEVICE_INTERFACE_LIST_PRESENT);

	CAtlString res = device_path;
	if (!device_path[0]) //4 Vista
	{
		HDEVINFO hDevsInfo = ::SetupDiGetClassDevs(&interface_guid, NULL, 0, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);
		if (hDevsInfo != INVALID_HANDLE_VALUE)
		{
			for (DWORD dev_index = 0; ; ++dev_index)
			{
				SP_DEVICE_INTERFACE_DATA deviface_data = {0};
				deviface_data.cbSize = sizeof(deviface_data);

				if (::SetupDiEnumDeviceInterfaces(hDevsInfo, NULL, &interface_guid, dev_index, &deviface_data))
				{				
					res = DeviceEnumFunc(hDevsInfo, deviface_data, device_inst, device_id);
					if (res.IsEmpty())
					{
						continue;
					}
				}
				break;
			}

			::SetupDiDestroyDeviceInfoList(hDevsInfo);
		}
	}

	return res;
}

MXDeviceEnumerator::DeviceInfo::vector_t MXDeviceEnumerator::EnumerateMaximuses()
{
	DeviceInfo::vector_t res;

	HDEVINFO hDevsInfo = ::SetupDiGetClassDevs(NULL, g_HubVidPid, 0, DIGCF_PRESENT | DIGCF_ALLCLASSES);
	if (hDevsInfo != INVALID_HANDLE_VALUE)
	{
		for (DWORD class_index = 0; ; ++class_index)
		{
			SP_DEVINFO_DATA DeviceInfoData = {0};
			DeviceInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
		
			if (::SetupDiEnumDeviceInfo(hDevsInfo, class_index, &DeviceInfoData))
			{				
				DeviceInfo device_info;

				EnumerateDeviceTree(0, DeviceInfoData.DevInst, device_info, false);

				if (device_info.isComplete())
				{
					res.push_back(device_info);
				}
			}
			else
			{
				break;
			}
		}

		::SetupDiDestroyDeviceInfoList(hDevsInfo);
	}

	return res;
}

bool MXDeviceEnumerator::ProcessDevice(TCHAR* DeviceID, DEVINST device_inst, DeviceInfo& device_info, bool is_vdrive_branch)
{
	if (is_vdrive_branch || isMaximsDriveDevice(DeviceID))
	{
		device_info.VDriveDevicePath = getDevicePath(DeviceID, GUID_DEVINTERFACE_VOLUME, device_inst); 
		device_info.VDriveVolumeName = getVolumeName(device_info.VDriveDevicePath);
		device_info.VDriveLetter = VolumeName2DriveLetter(device_info.VDriveVolumeName);

		is_vdrive_branch = true;
	}
	else 
	{
		const static GUID GUID_HIDCLASS = {0x4D1E55B2L, 0xF16F, 0x11CF, {0x88, 0xCB, 0x00, 0x11, 0x11, 0x00, 0x00, 0x30}};

		if (isMultimediaHidEndpoint(DeviceID))
		{
			device_info.MultimediaHidEndpointDevicePath = getDevicePath(DeviceID, GUID_HIDCLASS, device_inst);
		}
		else if (isInternalHidEndpoint(DeviceID))
		{
			device_info.InternalHidEndpointDevicePath = getDevicePath(DeviceID, GUID_HIDCLASS, device_inst);
		}
	}

    return is_vdrive_branch;
}

void MXDeviceEnumerator::EnumerateDeviceTree(size_t level, DEVINST device_inst, DeviceInfo& device_info, bool is_vdrive_branch)
{
	TCHAR DeviceID[MAX_DEVICE_ID_LEN] = {0};
	::CM_Get_Device_ID(device_inst, DeviceID, MAX_DEVICE_ID_LEN, 0);
	_tcsupr(DeviceID);

    is_vdrive_branch = level > 0 && !isHubEndpoint(DeviceID) && ProcessDevice(DeviceID, device_inst, device_info, is_vdrive_branch);

    DEVINST device_ret = {0};
	if (::CM_Get_Child(&device_ret, device_inst, 0) == CR_SUCCESS) 
	{
		EnumerateDeviceTree(level + 1, device_ret, device_info, is_vdrive_branch);
        
		while (::CM_Get_Sibling(&device_ret, device_ret, 0) == CR_SUCCESS)
		{
			EnumerateDeviceTree(level + 1, device_ret, device_info, is_vdrive_branch);
		}                
    }
}