#ifndef MX_BUTTONS_H
#define MX_BUTTONS_H

#include "MaximusDefaults.h"

enum MXConstants
{
	MXKeyHeight = 48,
	MXKeyWidth  = 48,
	MXKeySquare = MXKeyHeight*MXKeyWidth
};

enum MXKeyFlags
{
	mxkfNone     = 0,
	mxkfSystem   = 1 << 0,
	mxkfNumBlock = 1 << 1,
	mxkfLock     = 1 << 2,
	mxkfFunction = 1 << 3,
	mxkfModifier = 1 << 4,
	mxkfOptExt   = 1 << 5,
	mxkfHLeft    = 1 << 6,
	mxkfHRight   = 1 << 7,

	mxkfNoAlphabetical = mxkfOptExt | mxkfSystem | mxkfNumBlock
};

struct MXButtonInfo
{
	unsigned int winVK;	
	MXScanCode   scanCode;

	BYTE oledIndex; // button image filename has form x{oledIndex}
	BYTE keyIndex;  // specifies key number in scancodes.sys file
	MXActionCode actionCode; // default action code in en_US layout

	const TCHAR* keyName;
	const TCHAR* keyDisplayName;

	BYTE flags;
};

const static MXButtonInfo g_KeyboardButtons[] = 
{
	{ VK_ESCAPE,           1,  99,   8, 0x29, _T("Escape"),           _T("Esc"),    mxkfSystem | mxkfHLeft},	// esc key
	{ VK_F1,              59, 100,  16, 0x3A, _T("F1"),               _T("F1"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F1 key
	{ VK_F2,              60, 101,  24, 0x3B, _T("F2"),               _T("F2"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F2 key
	{ VK_F3,              61, 102,  32, 0x3C, _T("F3"),               _T("F3"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F3 key
	{ VK_F4,              62, 103,  40, 0x3D, _T("F4"),               _T("F4"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F4 key
	{ VK_F5,              63, 104,  48, 0x3E, _T("F5"),               _T("F5"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F5 key
	{ VK_F6,              64, 105,  56, 0x3F, _T("F6"),               _T("F6"),     mxkfSystem | mxkfFunction | mxkfHLeft },	// F6 key
	{ VK_F7,              65, 106,  64, 0x40, _T("F7"),               _T("F7"),     mxkfSystem | mxkfFunction | mxkfHRight },	// F7 key
	{ VK_F8,              66, 107,  72, 0x41, _T("F8"),               _T("F8"),     mxkfSystem | mxkfFunction | mxkfHRight },	// F8 key
	{ VK_F9,              67, 108,  80, 0x42, _T("F9"),               _T("F9"),     mxkfSystem | mxkfFunction | mxkfHRight },	// F9 key
	{ VK_F10,             68, 109,  88, 0x43, _T("F10"),              _T("F10"),    mxkfSystem | mxkfFunction | mxkfHRight },	// F10 key
	{ VK_F11,             87, 110,  96, 0x44, _T("F11"),              _T("F11"),    mxkfSystem | mxkfFunction | mxkfHRight },	// F11 key
	{ VK_F12,             88, 111, 104, 0x45, _T("F12"),              _T("F12"),	mxkfSystem | mxkfFunction | mxkfHRight },	// F12 key
	{ VK_SNAPSHOT,        84, 112,   2, 0x46, _T("PrintScreen"),      _T("PrtScr"), mxkfSystem },	// prtscr key
	{ VK_SCROLL,          70, 113,  10, 0x47, _T("ScrollLock"),       _T("Scroll"), mxkfSystem | mxkfLock },	// scrlck key
	{ VK_PAUSE,           89, 114,  18, 0x48, _T("Pause"),            _T("Pause"),  mxkfSystem },	// pause key          //16
																						
	{ 0,                   0,  97,   7, 0x00, _T("L1"),               _T("L1"),     mxkfOptExt | mxkfHLeft },	// L1 key
	{ 0,                   0,  98,  47, 0x00, _T("L2"),               _T("L2"),     mxkfOptExt | mxkfHLeft },	// L2 key
	{ VK_OEM_3,           41,  88,   6, 0x35, _T("GraveAccent"),      _T("`"),	    mxkfHLeft },	// ` key
	{ '1',                 2,  87,  14, 0x1E, _T("1"),                _T("1"),      mxkfHLeft },	// 1 key
	{ '2',                 3,  74,  22, 0x1F, _T("2"),                _T("2"),      mxkfHLeft },	// 2 key
	{ '3',                 4,  73,  30, 0x20, _T("3"),                _T("3"),      mxkfHLeft },	// 3 key
	{ '4',                 5,  72,  38, 0x21, _T("4"),                _T("4"),      mxkfHLeft },	// 4 key
	{ '5',                 6,  71,  46, 0x22, _T("5"),                _T("5"),      mxkfHLeft },	// 5 key
	{ '6',                 7,  58,  54, 0x23, _T("6"),                _T("6"),      mxkfHLeft },	// 6 key
	{ '7',                 8,  57,  62, 0x24, _T("7"),                _T("7"),      mxkfHRight },	// 7 key
	{ '8',                 9,  56,  70, 0x25, _T("8"),                _T("8"),      mxkfHRight },	// 8 key
	{ '9',                10,  55,  78, 0x26, _T("9"),                _T("9"),      mxkfHRight },	// 9 key
	{ '0',                11,  42,  86, 0x27, _T("0"),                _T("0"),      mxkfHRight },	// 0 key
	{ VK_OEM_MINUS,       12,  41,  94, 0x2D, _T("Minus"),            _T("-"),	    mxkfHRight },	// - key
	{ VK_OEM_PLUS,        13,  40, 102, 0x2E, _T("Plus"),             _T("+"),	    mxkfHRight },	// = key
	{ VK_BACK,            14,  39, 110, 0x2A, _T("Backspace"),        _T("Back"),	mxkfSystem | mxkfHRight },	// bksp key
	{ VK_INSERT,          82,  21,  26, 0x49, _T("Insert"),           _T("Ins"),	mxkfSystem },	// ins key
	{ VK_HOME,            71,  20,  34, 0x4A, _T("Home"),             _T("Home"),   mxkfSystem },	// home key
	{ VK_PRIOR,           73,  19,  42, 0x4B, _T("PageUp"),           _T("PgUp"),	mxkfSystem },	// pgup key
	{ VK_NUMLOCK,         69,  18,   1, 0x53, _T("NumLock"),          _T("Num"),	mxkfSystem | mxkfLock | mxkfNumBlock },	// nlck key
	{ VK_DIVIDE,          53,  17,   9, 0x54, _T("KeypadDivide"),     _T("/"),	    mxkfNumBlock },	// n/ key
	{ VK_MULTIPLY,        55,  16,  17, 0x55, _T("KeypadMultiply"),   _T("*"),	    mxkfNumBlock },	// n* key
	{ VK_SUBTRACT,        74,  15,  25, 0x56, _T("KeypadMinus"),      _T("-"),	    mxkfNumBlock },	// n- key             //23
																						
	{ 0,                   0,  96,  15, 0x00, _T("L3"),               _T("L3"),     mxkfOptExt | mxkfHLeft },	// L3 key
	{ 0,                   0,  89,  55, 0x00, _T("L4"),               _T("L4"),     mxkfOptExt | mxkfHLeft },	// L4 key
	{ VK_TAB,             15,  85,   5, 0x2B, _T("Tab"),              _T("Tab"),    mxkfSystem | mxkfHLeft },	// tab key
	{ 'Q',                16,  86,  13, 0x14, _T("Q"),                _T("Q"),      mxkfHLeft },	// q key
	{ 'W',                17,  75,  21, 0x1A, _T("W"),                _T("W"),      mxkfHLeft },	// w key
	{ 'E',                18,  69,  29, 0x08, _T("E"),                _T("E"),      mxkfHLeft },	// e key
	{ 'R',                19,  70,  37, 0x15, _T("R"),                _T("R"),      mxkfHLeft },	// r key
	{ 'T',                20,  59,  45, 0x17, _T("T"),                _T("T"),      mxkfHLeft },	// t key
	{ 'Y',                21,  60,  53, 0x1C, _T("Y"),                _T("Y"),      mxkfHRight },	// y key
	{ 'U',                22,  54,  61, 0x18, _T("U"),                _T("U"),      mxkfHRight },	// u key
	{ 'I',                23,  53,  69, 0x0C, _T("I"),                _T("I"),      mxkfHRight },	// i key
	{ 'O',                24,  43,  77, 0x12, _T("O"),                _T("O"),      mxkfHRight },	// o key
	{ 'P',                25,  44,  85, 0x13, _T("P"),                _T("P"),      mxkfHRight },	// p key
	{ VK_OEM_4,           26,  38,  93, 0x2F, _T("BraceSquareLeft"),  _T("["),	    mxkfHRight },	// [ key
	{ VK_OEM_6,           27,  37, 101, 0x30, _T("BraceSquareRight"), _T("]"),	    mxkfHRight },	// ] key
	{ VK_OEM_5,           43,  36, 109, 0x31, _T("StraightSlash"),    _T("\\"),		mxkfHRight },	// \ key
	{ VK_DELETE,          83,  22,  50, 0x4C, _T("Delete"),           _T("Del"),    mxkfSystem },	// del key
	{ VK_END,             79,  23,  58, 0x4D, _T("End"),              _T("End"),    mxkfSystem },	// end key
	{ VK_NEXT,            81,  24,  66, 0x4E, _T("PageDown"),         _T("PgDn"),   mxkfSystem },	// pgdn key
	{ VK_NUMPAD7,         71,  11,  33, 0x5F, _T("Keypad7"),          _T("7"),      mxkfNumBlock },	// n7 key
	{ VK_NUMPAD8,         72,  12,  41, 0x60, _T("Keypad8"),          _T("8"),      mxkfNumBlock },	// n8 key
	{ VK_NUMPAD9,         73,  13,  49, 0x61, _T("Keypad9"),          _T("9"),      mxkfNumBlock },	// n9 key             //22
																						
	{ 0,                   0,  95,  23, 0x00, _T("L5"),               _T("L5"),     mxkfOptExt | mxkfHLeft },	// L5 key
	{ 0,                   0,  90,  63, 0x00, _T("L6"),               _T("L6"),     mxkfOptExt | mxkfHLeft },	// L6 key
	{ VK_CAPITAL,         58,  84,   4, 0x39, _T("CapsLock"),         _T("Caps"),	mxkfSystem | mxkfLock | mxkfHLeft },	// caps key
	{ 'A',                30,  83,  12, 0x04, _T("A"),                _T("A"),      mxkfHLeft },	// a key (it's vcode is zero, exactly)
	{ 'S',                31,  76,  20, 0x16, _T("S"),                _T("S"),      mxkfHLeft },	// s key
	{ 'D',                32,  68,  28, 0x07, _T("D"),                _T("D"),      mxkfHLeft },	// d key
	{ 'F',                33,  67,  36, 0x09, _T("F"),                _T("F"),      mxkfHLeft },	// f key
	{ 'G',                34,  62,  44, 0x0A, _T("G"),                _T("G"),      mxkfHLeft },	// g key
	{ 'H',                35,  61,  52, 0x0B, _T("H"),                _T("H"),      mxkfHRight },	// h key
	{ 'J',                36,  51,  60, 0x0D, _T("J"),                _T("J"),      mxkfHRight },	// j key
	{ 'K',                37,  52,  68, 0x0E, _T("K"),                _T("K"),      mxkfHRight },	// k key
	{ 'L',                38,  46,  76, 0x0F, _T("L"),                _T("L"),      mxkfHRight },	// l key
	{ VK_OEM_1,           39,  45,  84, 0x33, _T("Semicolon"),        _T(";"),		mxkfHRight },	// ; key
	{ VK_OEM_7,           40,  34,  92, 0x34, _T("Quote"),            _T("\""),		mxkfHRight },	// ' key
	{ VK_RETURN,          28,  35, 100, 0x28, _T("Return"),           _T("Enter"),	mxkfSystem | mxkfHRight },	// enter key
	{ VK_NUMPAD4,         75,  10,  65, 0x5C, _T("Keypad4"),          _T("4"),		mxkfNumBlock },	// n4 key
	{ VK_NUMPAD5,         76,   9,  73, 0x5D, _T("Keypad5"),          _T("5"),		mxkfNumBlock },	// n5 key
	{ VK_NUMPAD6,         77,   8,  81, 0x5E, _T("Keypad6"),          _T("6"),		mxkfNumBlock },	// n6 key
	{ VK_ADD,             78,  14,  57, 0x57, _T("KeypadPlus"),       _T("+"),		mxkfNumBlock },	// n+ key                    //19
																						
	{ 0,                   0,  94,  31, 0x00, _T("L7"),               _T("L7"),     mxkfOptExt | mxkfHLeft },	// L7 key
	{ 0,                   0,  91,  71, 0x00, _T("L8"),               _T("L8"),     mxkfOptExt | mxkfHLeft },	// L8 key
	{ VK_LSHIFT,          42,  82,   3, 0x73, _T("ShiftLeft"),        _T("Shift"),	mxkfSystem | mxkfModifier | mxkfHLeft },	// shift key
	{ 'Z',                44,  77,  11, 0x1D, _T("Z"),                _T("Z"),      mxkfHLeft },	// z key
	{ 'X',                45,  66,  19, 0x1B, _T("X"),                _T("X"),      mxkfHLeft },	// x key
	{ 'C',                46,  65,  27, 0x06, _T("C"),                _T("C"),      mxkfHLeft },	// c key
	{ 'V',                47,  63,  35, 0x19, _T("V"),                _T("V"),      mxkfHLeft },	// v key
	{ 'B',                48,  64,  43, 0x05, _T("B"),                _T("B"),      mxkfHLeft },	// b key
	{ 'N',                49,  50,  51, 0x11, _T("N"),                _T("N"),      mxkfHRight },	// n key
	{ 'M',                50,  49,  59, 0x10, _T("M"),                _T("M"),      mxkfHRight },	// m key
	{ VK_OEM_COMMA,       51,  48,  67, 0x36, _T("Comma"),            _T(","),		mxkfHRight },	// , key
	{ VK_OEM_PERIOD,      52,  47,  75, 0x37, _T("Dot"),              _T("."),		mxkfHRight },	// . key
	{ VK_OEM_2,           53,  33,  83, 0x38, _T("Slash"),            _T("/"),		mxkfHRight },	// / key
	{ VK_RSHIFT,          54,  30,  91, 0x77, _T("ShiftRight"),       _T("Shift"),	mxkfSystem | mxkfModifier | mxkfHRight },	// shift key
	{ VK_UP,              72,  27,  74, 0x52, _T("UpArrow"),          _T("Up"),		mxkfSystem },	// up key
	{ VK_NUMPAD1,         79,   6,  97, 0x59, _T("Keypad1"),          _T("1"),		mxkfNumBlock },	// n1 key
	{ VK_NUMPAD2,         80,   5, 105, 0x5A, _T("Keypad2"),          _T("2"),		mxkfNumBlock },	// n2 key
	{ VK_NUMPAD3,         81,   4, 113, 0x5B, _T("Keypad3"),          _T("3"),		mxkfNumBlock },	// n3 key                 //18
																						
	{ 0,                   0,  93,  39, 0x00, _T("L9"),               _T("L9"),     mxkfOptExt | mxkfHLeft },	// L9 key
	{ 0,                   0,  92,  79, 0x00, _T("L10"),              _T("L10"),    mxkfOptExt | mxkfHLeft },	// L10 key
	{ VK_LCONTROL,        29,  81,  87, 0x72, _T("CtrlLeft"),         _T("Ctrl"),	mxkfSystem | mxkfModifier | mxkfHLeft },	// ctrl key
	{ VK_LWIN,            91,  80,  95, 0x75, _T("CmdLeft"),          _T("Win"),    mxkfSystem | mxkfModifier | mxkfHLeft },	// win key
	{ VK_LMENU,           56,  79, 103, 0x74, _T("AltLeft"),          _T("Alt"),    mxkfSystem | mxkfModifier | mxkfHLeft },	// alt key
	{ VK_SPACE,           57,  78, 111, 0x2C, _T("Spacebar"),         _T("Space"),	mxkfHLeft  | mxkfHRight },	// space key
	{ VK_RMENU,           56,  32, 119, 0x78, _T("AltRight"),         _T("AltGr"),	mxkfSystem | mxkfModifier | mxkfHRight },	// alt key
	{ VK_APPS,            93,  31, 127, 0x65, _T("CmdRight"),         _T("Apps"),   mxkfSystem | mxkfHRight },	// ctx key
	{ VK_RCONTROL,        29,  29, 135, 0x76, _T("CtrlRight"),        _T("Ctrl"),	mxkfSystem | mxkfModifier | mxkfHRight },	// ctrl key
	{ VK_LEFT,            75,  28,  82, 0x50, _T("LeftArrow"),        _T("Left"),	mxkfSystem },	// left key
	{ VK_DOWN,            80,  26,  90, 0x51, _T("DownArrow"),        _T("Down"),	mxkfSystem },	// down key
	{ VK_RIGHT,           77,  25,  98, 0x4F, _T("RightArrow"),       _T("Right"),	mxkfSystem },	// right key
	{ VK_NUMPAD0,         82,   1, 121, 0x62, _T("Keypad0"),          _T("0"),		mxkfNumBlock },	// n0 key
	{ VK_DECIMAL,         83,   2, 129, 0x63, _T("KeypadDot"),        _T("."),		mxkfNumBlock },	// n. key
	{ VK_RETURN,          28,   3, 137, 0x58, _T("KeypadEnter"),      _T("Enter"),	mxkfSystem | mxkfNumBlock },	// nenter key       //15
	
	{ 0 }
};

const size_t MXKeyCount = sizeof(g_KeyboardButtons)/sizeof(MXButtonInfo) - 1;

#endif //MX_BUTTONS_H