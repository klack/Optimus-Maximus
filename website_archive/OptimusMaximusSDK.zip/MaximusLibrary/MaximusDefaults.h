#ifndef MAXIMUS_LIBRARY_H
#define MAXIMUS_LIBRARY_H

typedef unsigned char MXScanCode;
typedef unsigned char MXActionCode;

#endif MAXIMUS_LIBRARY_H