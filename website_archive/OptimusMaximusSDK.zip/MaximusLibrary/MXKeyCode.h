#ifndef MX_KEY_INFO_H
#define MX_KEY_INFO_H

#include "MaximusDefaults.h" //4MXActionCode

/*
	������ ���� "������" �� ���������
*/

struct MXKeyCodeInfo
{
	const TCHAR*  actionName;
	MXActionCode  actionCode;
};

const static MXKeyCodeInfo g_KeyInfo[] =
{
	{ _T("a"),	0x4 },
	{ _T("b"),	0x5 },
	{ _T("c"),	0x6 },
	{ _T("d"),	0x7 },
	{ _T("e"),	0x8 },
	{ _T("f"),	0x9 },
	{ _T("g"),	0xA },
	{ _T("h"),	0xB },
	{ _T("i"),	0xC },
	{ _T("j"),	0xD },
	{ _T("k"),	0xE },
	{ _T("l"),	0xF },
	{ _T("m"),	0x10 },
	{ _T("n"),	0x11 },
	{ _T("o"),	0x12 },
	{ _T("p"),	0x13 },
	{ _T("q"),	0x14 },
	{ _T("r"),	0x15 },
	{ _T("s"),	0x16 },
	{ _T("t"),	0x17 },
	{ _T("u"),	0x18 },
	{ _T("v"),	0x19 },
	{ _T("w"),	0x1A },
	{ _T("x"),	0x1B },
	{ _T("y"),	0x1C },
	{ _T("z"),	0x1D },
	{ _T("1"),	0x1E },
	{ _T("2"),	0x1F },
	{ _T("3"),	0x20 },
	{ _T("4"),	0x21 },
	{ _T("5"),	0x22 },
	{ _T("6"),	0x23 },
	{ _T("7"),	0x24 },
	{ _T("8"),	0x25 },
	{ _T("9"),	0x26 },
	{ _T("0"),	0x27 },
	
	{ _T("enter"),	0x28 },
	{ _T("esc"),	0x29 },
	{ _T("bs"),	0x2A },
	{ _T("tab"),	0x2B },
	{ _T("space"),	0x2C },
	{ _T("neg"),	0x2D },
	{ _T("equation"),	0x2E },
	{ _T("L_brackets"),	0x2F },
	{ _T("R_brackets"),	0x30 },
	{ _T("code29 (/)"),	0x31 },
	{ _T("code42"),	0x32 },
	{ _T("semicolon"),	0x33 },
	{ _T("apostrophe"),	0x34 },
	{ _T("tilde (~)"),	0x35 },
	{ _T("comma"),	0x36 },
	{ _T("dot"),	0x37 },
	{ _T("interrogation"),	0x38 },
	{ _T("cap"),	0x39 },
	
	{ _T("f1"),	0x3A },
	{ _T("f2"),	0x3B },
	{ _T("f3"),	0x3C },
	{ _T("F4"),	0x3D },
	{ _T("f5"),	0x3E },
	{ _T("F6"),	0x3F },
	{ _T("f7"),	0x40 },
	{ _T("f8"),	0x41 },
	{ _T("f9"),	0x42 },
	{ _T("f10"),	0x43 },
	{ _T("f11"),	0x44 },
	{ _T("f12"),	0x45 },
	
	{ _T("print"),	0x46 },
	{ _T("scroll"),	0x47 },
	{ _T("pause"),	0x48 },
	
	{ _T("insert"),	0x49 },
	{ _T("home"),	0x4A },
	{ _T("pgup"),	0x4B },
	{ _T("del"),	0x4C },
	{ _T("end"),	0x4D },
	{ _T("pgdn"),	0x4E },
	
	{ _T("R_arrow"),	0x4F },
	{ _T("L_arrow"),	0x50 },
	{ _T("dn_arrow"),	0x51 },
	{ _T("Up_arrow"),	0x52 },
	
	{ _T("num_lock"),	0x53 },
	{ _T("num_div"),	0x54 },
	{ _T("num_star"),	0x55 },
	{ _T("num_neg"),	0x56 },
	{ _T("num_plus"),	0x57 },
	{ _T("num_enter"),	0x58 },
	{ _T("num_1"),	0x59 },
	{ _T("num_2"),	0x5A },
	{ _T("num_3"),	0x5B },
	{ _T("num_4"),	0x5C },
	{ _T("num_5"),	0x5D },
	{ _T("num_6"),	0x5E },
	{ _T("num_7"),	0x5F },
	{ _T("num_8"),	0x60 },
	{ _T("num_9"),	0x61 },
	{ _T("num_0"),	0x62 },
	{ _T("num_dot"),	0x63 },
	
	{ _T("\\"),	0x64 },
	{ _T("app"),	0x65 },
	{ _T("padequ"),	0x66 },
	{ _T("f13"),	0x67 },
	{ _T("f14"),	0x68 },
	{ _T("f15"),	0x69 },
	{ _T("code107"),0x6A },
	{ _T("code56"),	0x6B },
	{ _T("code133"),0x6C },
	{ _T("code14"),	0x6D },
	{ _T("code132"),0x6E },
	{ _T("code131"),0x6F },
	{ _T("Hangul"),	0x70 },
	{ _T("Hanja"),	0x71 },
	{ _T("L_ctrl"),	0x72 },
	{ _T("l_shift"),0x73 },
	{ _T("l_alt"),	0x74 },
	{ _T("L_win"),	0x75 },
	{ _T("r_ctrl"),	0x76 },
	{ _T("r_shift"),0x77 },
	{ _T("r_alt"),	0x78 },
	{ _T("r_win"),	0x79 },
	{ _T("help"),	0x7A },
	{ _T("Media mute"),	0x7B },
	{ _T("Media vol down"),	0x7C },
	{ _T("Media vol up"),	0x7D },
	{ _T("word"),	0x7E },
	{ _T("excel"),	0x7F },
	{ _T("mail"),	0x80 },
	{ _T("calender"),	0x81 },
	{ _T("calculator"),	0x82 },
	{ _T("log_off"),	0x83 },
	{ _T("app_l"),	0x84 },
	{ _T("app_r"),	0x85 },
	{ _T("task_pane"),	0x86 },
	{ _T("spell"),	0x87 },
	{ _T("files"),	0x88 },
	{ _T("new"),	0x89 },
	{ _T("open"),	0x8A },
	{ _T("close"),	0x8B },
	{ _T("save"),	0x8C },
	{ _T("f12_print"),	0x8D },
	{ _T("undo"),	0x8E },
	{ _T("copy"),	0x8F },
	{ _T("cut"),	0x90 },
	{ _T("paste"),	0x91 },
	{ _T("office_home"),	0x92 },
	{ _T("Browser home"),	0x93 },
	{ _T("Browser back"),	0x94 },
	{ _T("Browser forward"),0x95 },
	{ _T("redo"),	0x96 },
	{ _T("reply"),	0x97 },
	{ _T("forward"),0x98 },
	{ _T("send"),	0x99 },
	{ _T("Media next track"),	0x9A },
	{ _T("Media prev track"),	0x9B },
	{ _T("Media stop"),	0x9C },
	{ _T("Media play"),	0x9D },
	{ _T("media sel"),	0x9E },
	{ _T("my_computer"),0x9F },
	{ _T("Browser search"),	0xA0 },
	{ _T("Browser stop"),	0xA1 },
	{ _T("Browser reload"),	0xA2 },
	{ _T("Browser favorites"),	0xA3 },
	{ _T("System power"),	0xA4 },
	{ _T("System sleep"),	0xA5 },
	{ _T("System wake up"),	0xA6 },
	{ _T("fn"),	0xA7 },

	{0}
};

const size_t MXKeyInfoCount = sizeof(g_KeyInfo)/sizeof(MXKeyCodeInfo) - 1;

const static BYTE g_vk2keycode[] =
{
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  42 },	 //Backspace
	{  43 },	 //Tab
//10
	{   0 },
	{   0 },
	{   0 },
	{  88 },	 //KeypadEnter
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  72 },	 //Pause
//20
	{  57 },	 //CapsLock
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  41 },	 //Escape
	{   0 },
	{   0 },
//30
	{   0 },
	{   0 },
	{  44 },	 //Spacebar
	{  75 },	 //PageUp
	{  78 },	 //PageDown
	{  77 },	 //End
	{  74 },	 //Home
	{  80 },	 //LeftArrow
	{  82 },	 //UpArrow
	{  79 },	 //RightArrow
//40
	{  81 },	 //DownArrow
	{   0 },
	{   0 },
	{   0 },
	{  70 },	 //PrintScreen
	{  73 },	 //Insert
	{  76 },	 //Delete
	{   0 },
	{  39 },	 //0
	{  30 },	 //1
//50
	{  31 },	 //2
	{  32 },	 //3
	{  33 },	 //4
	{  34 },	 //5
	{  35 },	 //6
	{  36 },	 //7
	{  37 },	 //8
	{  38 },	 //9
	{   0 },
	{   0 },
//60
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   4 },	 //A
	{   5 },	 //B
	{   6 },	 //C
	{   7 },	 //D
	{   8 },	 //E
//70
	{   9 },	 //F
	{  10 },	 //G
	{  11 },	 //H
	{  12 },	 //I
	{  13 },	 //J
	{  14 },	 //K
	{  15 },	 //L
	{  16 },	 //M
	{  17 },	 //N
	{  18 },	 //O
//80
	{  19 },	 //P
	{  20 },	 //Q
	{  21 },	 //R
	{  22 },	 //S
	{  23 },	 //T
	{  24 },	 //U
	{  25 },	 //V
	{  26 },	 //W
	{  27 },	 //X
	{  28 },	 //Y
//90
	{  29 },	 //Z
	{ 117 },	 //CmdLeft
	{   0 },
	{ 101 },	 //CmdRight
	{   0 },
	{   0 },
	{  98 },	 //Keypad0
	{  89 },	 //Keypad1
	{  90 },	 //Keypad2
	{  91 },	 //Keypad3
//100
	{  92 },	 //Keypad4
	{  93 },	 //Keypad5
	{  94 },	 //Keypad6
	{  95 },	 //Keypad7
	{  96 },	 //Keypad8
	{  97 },	 //Keypad9
	{  85 },	 //KeypadMultiply
	{  87 },	 //KeypadPlus
	{   0 },
	{  86 },	 //KeypadMinus
//110
	{  99 },	 //KeypadDot
	{  84 },	 //KeypadDivide
	{  58 },	 //F1
	{  59 },	 //F2
	{  60 },	 //F3
	{  61 },	 //F4
	{  62 },	 //F5
	{  63 },	 //F6
	{  64 },	 //F7
	{  65 },	 //F8
//120
	{  66 },	 //F9
	{  67 },	 //F10
	{  68 },	 //F11
	{  69 },	 //F12
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//130
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//140
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  83 },	 //NumLock
	{  71 },	 //ScrollLock
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//150
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//160
	{ 115 },	 //ShiftLeft
	{ 119 },	 //ShiftRight
	{ 114 },	 //CtrlLeft
	{ 118 },	 //CtrlRight
	{ 116 },	 //AltLeft
	{ 120 },	 //AltRight
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//170
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//180
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  51 },	 //Semicolon
	{  46 },	 //Plus
	{  54 },	 //Comma
	{  45 },	 //Minus
//190
	{  55 },	 //Dot
	{  56 },	 //Slash
	{  53 },	 //GraveAccent
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//200
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
//210
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{   0 },
	{  47 },	 //BraceSquareLeft
//220
	{  49 },	 //StraightSlash
	{  48 },	 //BraceSquareRight
	{  52 } 	 //Quote
};

const size_t MXVK2codeCount = sizeof(g_vk2keycode)/sizeof(BYTE);

const static BYTE g_scan2keycode[] =
{
	{   0 },
	{  41 },	 //Escape
	{  30 },	 //1
	{  31 },	 //2
	{  32 },	 //3
	{  33 },	 //4
	{  34 },	 //5
	{  35 },	 //6
	{  36 },	 //7
	{  37 },	 //8
//10
	{  38 },	 //9
	{  39 },	 //0
	{  45 },	 //Minus
	{  46 },	 //Plus
	{  42 },	 //Backspace
	{  43 },	 //Tab
	{  20 },	 //Q
	{  26 },	 //W
	{   8 },	 //E
	{  21 },	 //R
//20
	{  23 },	 //T
	{  28 },	 //Y
	{  24 },	 //U
	{  12 },	 //I
	{  18 },	 //O
	{  19 },	 //P
	{  47 },	 //BraceSquareLeft
	{  48 },	 //BraceSquareRight
	{  88 },	 //KeypadEnter
	{ 118 },	 //CtrlRight
//30
	{   4 },	 //A
	{  22 },	 //S
	{   7 },	 //D
	{   9 },	 //F
	{  10 },	 //G
	{  11 },	 //H
	{  13 },	 //J
	{  14 },	 //K
	{  15 },	 //L
	{  51 },	 //Semicolon
//40
	{  52 },	 //Quote
	{  53 },         //GraveAccent
	{ 115 },	 //ShiftLeft
	{  49 },	 //StraightSlash
	{  29 },	 //Z
	{  27 },	 //X
	{   6 },	 //C
	{  25 },	 //V
	{   5 },	 //B
	{  17 },	 //N
//50
	{  16 },	 //M
	{  54 },	 //Comma
	{  55 },	 //Dot
	{  56 },	 //Slash
	{ 119 },	 //ShiftRight
	{  85 },	 //KeypadMultiply
	{ 120 },	 //AltRight
	{  44 },	 //Spacebar
	{  57 },	 //CapsLock
	{  58 },	 //F1
//60
	{  59 },	 //F2
	{  60 },	 //F3
	{  61 },	 //F4
	{  62 },	 //F5
	{  63 },	 //F6
	{  64 },	 //F7
	{  65 },	 //F8
	{  66 },	 //F9
	{  67 },	 //F10
	{  83 },	 //NumLock
//70
	{  71 },	 //ScrollLock
	{  95 },	 //Keypad7
	{  82 },	 //UpArrow
	{  97 },	 //Keypad9
	{  86 },	 //KeypadMinus
	{  80 },	 //LeftArrow
	{  93 },	 //Keypad5
	{  79 },	 //RightArrow
	{  87 },	 //KeypadPlus
	{  89 },	 //Keypad1
//80
	{  81 },	 //DownArrow
	{  91 },	 //Keypad3
	{  98 },	 //Keypad0
	{  99 },	 //KeypadDot
	{  70 },	 //PrintScreen
	{   0 },
	{   0 },
	{  68 },	 //F11
	{  69 },	 //F12
	{  72 },	 //Pause
//90
	{   0 },
	{ 117 },	 //CmdLeft
	{   0 },
	{ 101 } 	 //CmdRight
};

const size_t MXScan2codeCount = sizeof(g_scan2keycode)/sizeof(BYTE);

/* // The arrays above were generated using the following code

#include "stdafx.h"

#include <windows.h>

#include "MXButtons.h"
#include "MXButtonsTypes.h"

#include <vector>
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	struct dump_data_t
	{
		BYTE key_code;
		const TCHAR* key_name;

		dump_data_t():key_code(0), key_name(0){}
	};

	typedef vector<dump_data_t> dump_vector_t;

	dump_vector_t vk2code(256);
	dump_vector_t scan2code(128);

	for (size_t ii = 0; ii < MXKeyCount; ++ii)
	{
		const MXButtonInfo& button_info = g_KeyboardButtons[ii];

		vk2code[button_info.winVK].key_code      = button_info.keyCode;
		scan2code[button_info.scanCode].key_code = button_info.keyCode;

		vk2code[button_info.winVK].key_name = scan2code[button_info.scanCode].key_name = button_info.keyName;
	}

	ofstream file("dump.h");

	file << "BYTE g_vk2keycode[] =\n{\n";
	for (size_t ii = 0; ii < vk2code.size(); ++ii)
	{
		file << "\t{ " << setw(3) << int(vk2code[ii].key_code) << " },";

		if (vk2code[ii].key_code && vk2code[ii].key_name)
		{
			file << "\t //" << string(vk2code[ii].key_name);
		}

		file << endl;
		if ((ii + 1) % 10 == 0)
		{
			file << "//" << ii + 1 << endl;
		}
	}

	file << "};\n\n";
	file << "const size_t MXVK2codeCount = sizeof(g_vk2keycode)/sizeof(BYTE);\n";
	file << "\n";

	file << "BYTE g_scan2keycode[] =\n{\n";
	for (size_t ii = 0; ii < scan2code.size(); ++ii)
	{
		file << "\t{ " << setw(3) << int(scan2code[ii].key_code) << " },";

		if (scan2code[ii].key_code && scan2code[ii].key_name)
		{
			file << "\t //" << string(scan2code[ii].key_name);
		}

		file << endl;
		if ((ii + 1) % 10 == 0)
		{
			file << "//" << ii + 1 << endl;
		}
	}

	file << "};\n\n";
	file << "const size_t MXScan2codeCount = sizeof(g_scan2keycode)/sizeof(BYTE);\n";

	return 0;
}
*/

#endif //MX_KEY_INFO_H