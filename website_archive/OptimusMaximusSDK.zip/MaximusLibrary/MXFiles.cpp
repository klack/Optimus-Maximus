#include "StdAfx.h"

#include "MXFiles.h"

bool MXBinaryFile::Open(LPCTSTR file_name, DWORD dwDesiredAccess /*= FILE_WRITE_DATA*/)
{
	Close();

	ATL::CHandle handle(::CreateFile(file_name, dwDesiredAccess, 0, NULL, OPEN_ALWAYS, FILE_FLAG_NO_BUFFERING | FILE_FLAG_WRITE_THROUGH, NULL));
	if (handle != INVALID_HANDLE_VALUE)
	{
		m_Handle = handle;
	}

	return m_Handle != NULL;
}

bool MXBinaryFile::WriteData(LPCVOID data, DWORD data_size)
{
	bool res = false;
	
	if (::SetFilePointer(m_Handle, 0, NULL, FILE_BEGIN) != INVALID_SET_FILE_POINTER)
	{
		DWORD bytes_written = 0;
		res = ::WriteFile(m_Handle, data, data_size, &bytes_written, NULL) == TRUE;
	}
	
	return res;
}

bool MXBinaryFile::ReadData(LPVOID data, DWORD data_size)
{
	bool res = false;
	
	if (::SetFilePointer(m_Handle, 0, NULL, FILE_BEGIN) != INVALID_SET_FILE_POINTER)
	{
		DWORD data_read = 0;
		res = ::ReadFile(m_Handle, data, data_size, &data_read, NULL) == TRUE;
	}

	return res;
}

void MXAsynchronousWriteFile::Reset()
{
	m_pBuffer = NULL; 
	m_pBuffer2 = NULL; 
	m_BufferSize = 0;

	m_Fresh = false;
}

bool MXAsynchronousWriteFile::Open()
{
	assert(!m_FileName.IsEmpty());
	return base_t::Open(m_FileName);
}

bool MXAsynchronousWriteFile::WriteData(LPCVOID data, DWORD data_size)
{
	bool res = false;

	assert(m_pBuffer);
	if (m_pBuffer)
	{
		assert(data_size <= m_BufferSize);
		m_Lock.Enter();

		if (data_size <= m_BufferSize && memcmp(m_Fresh ? m_pBuffer : m_pBuffer2, data, data_size))
		{
			memcpy(m_pBuffer, data, data_size);
			m_Fresh = true;

			res = true;
		}

		m_Lock.Leave();
	}

	return res;
}

bool MXAsynchronousWriteFile::FlushBuffer()
{
	bool res = false;

	if (m_Fresh)
	{
		assert(m_pBuffer);
		if (m_pBuffer)
		{
			const bool opened = IsOpened() || Open();
			assert(opened);
			if (opened)
			{
				m_Lock.Enter();
				std::swap(m_pBuffer, m_pBuffer2);
				m_Fresh = false;
				m_Lock.Leave();

				res = base_t::WriteData(m_pBuffer2, m_BufferSize);
			}
		}
	}

	return res;
}

void MXAsynchronousWriteFile::Close()
{
	Reset();
	base_t::Close();
}

void MXReadFile::Reset()
{
	m_pBuffer = NULL;
	m_BufferSize = 0;
}

BYTE* MXReadFile::ReadData()
{
	bool res = false;

	assert(m_pBuffer);
	if (m_pBuffer)
	{
		const bool opened = IsOpened() ? true : base_t::Open(m_FileName, FILE_READ_DATA);
		if (opened)
		{
			res = base_t::ReadData(m_pBuffer, m_BufferSize);
		}
	}

	return res ? m_pBuffer : NULL;
}

void MXReadFile::Close()
{
	Reset();
	base_t::Close();
}
