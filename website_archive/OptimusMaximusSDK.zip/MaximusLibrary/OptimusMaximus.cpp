#include "StdAfx.h"

#include <Dbt.h> //4 WM_DEVICECHANGE handling

#include <winioctl.h> //4 GUID_DEVINTERFACE_VOLUME

#include <algorithm>

#include "OptimusMaximus.h"

#include "MXKeyCode.h"
#include "MXDeviceEnumerator.h"

COptimusMaximus::COptimusMaximus(bool flag /*= true*/)
	:m_NeedUpdateEvent(TRUE, FALSE), m_ExitEvent(TRUE, FALSE), m_BytesPerSector(0), m_EventHandler(NULL), m_StartReadHIDEvent(TRUE, FALSE),
	m_needDelayAfterWritingScancodeSys(false)
{
	DWORD dwThreadId = 0;
	m_Thread = ATL::CHandle(::CreateThread(NULL, 0, flag ? &COptimusMaximus::ThreadProcWithWindow : &COptimusMaximus::ThreadProc, 
		this, 0, &dwThreadId));
}

COptimusMaximus::~COptimusMaximus()
{
	setDefaultScancodeSys();
	setAllKeysStatic();

	m_ExitEvent.Set();
	if (::WaitForSingleObject(m_Thread, 3000) == WAIT_TIMEOUT)
	{
		::TerminateThread(m_Thread, 0);
	}	

	disconnect();
}

inline void makeOLEDColor(CONST BYTE* rgb, BYTE* ptr)
{
	const unsigned char r = rgb[0];
	const unsigned char g = rgb[1] < 8 ? 0 : rgb[1]; // fix colors like 040404 "greening" due to extra green bit
	const unsigned char b = rgb[2];

    ptr[0]=(b&0xF8) + (g>>5);
    ptr[1]=(r>>3) + ((g&0xFC)<<3);
}

template <size_t bytes_per_color>
void convertRGB2OLED(CONST BYTE* rgb, BYTE* ptr)
{
    for (size_t yy = MXKeyHeight; yy >0 ; --yy){
        CONST BYTE* xrgb=rgb+(yy-1)*bytes_per_color*MXKeyWidth;
		for (size_t xx = 0; xx < MXKeyWidth; ++xx, xrgb += bytes_per_color, ptr += 2){
			makeOLEDColor(xrgb, ptr);
		}
	}
}

template <size_t bytes_per_color>
void convertRGB2OLEDRotated(CONST BYTE* rgb, BYTE* ptr)
{
	for (size_t xx = 0; xx < MXKeyWidth; ++xx){
		CONST BYTE* xrgb=rgb+xx*bytes_per_color;
		for (size_t yy = 0; yy < MXKeyHeight; ++yy, xrgb += bytes_per_color*MXKeyWidth, ptr += 2)
		{
			makeOLEDColor(xrgb, ptr);
		}
	}
}

void COptimusMaximus::convertRGB2OLED(CONST BYTE* srcbuf, BYTE* dstbuf)
{
	::convertRGB2OLED<3>(srcbuf, dstbuf);
}

void COptimusMaximus::convertRGB2OLEDRotate(CONST BYTE* srcbuf, BYTE* dstbuf)
{
	convertRGB2OLEDRotated<3>(srcbuf, dstbuf);
}

void COptimusMaximus::convertRGBA2OLED(CONST BYTE* srcbuf, BYTE* dstbuf)
{
	::convertRGB2OLED<4>(srcbuf, dstbuf);
}

void COptimusMaximus::convertRGBA2OLEDRotate(CONST BYTE* srcbuf, BYTE* dstbuf)
{
	convertRGB2OLEDRotated<4>(srcbuf, dstbuf);
}

inline size_t make_divisible(size_t val, size_t div)
{
	return (val + div - 1) & ~(div - 1);
}

inline BYTE* make_divisible(BYTE* val, size_t div)
{
	return (BYTE*)make_divisible(size_t(val), div);
}

inline BYTE* setFileParams(MXReadFile& file, LPCTSTR file_name, BYTE* buffer, size_t buff_size)
{
	file.SetFile(file_name);
	file.SetBuffer(buffer, DWORD(buff_size));
	return buffer + buff_size;
}

inline BYTE* setFileParams(MXAsynchronousWriteFile& file, LPCTSTR file_name, BYTE* buffer, size_t buff_size)
{
	file.SetFile(file_name);
	file.SetBuffer(buffer, buffer + buff_size, DWORD(buff_size));
	return buffer + 2*buff_size;
}

bool COptimusMaximus::initFiles()
{
	bool res = false;

	//Buffer sizes should aligned to sector size
	const size_t picture_div_size      = make_divisible(MXOledPictureSize, m_BytesPerSector);
	const size_t layouts_sys_div_size  = make_divisible(MXLayoutSysSize,   m_BytesPerSector);
	const size_t scancode_sys_div_size = make_divisible(MXScancodeSysSize, m_BytesPerSector);
	const size_t version_sys_div_size  = make_divisible(MXVersionSysSize,  m_BytesPerSector);
	const size_t order_sys_div_size    = make_divisible(MXOrderSysSize,    m_BytesPerSector);

	m_Buffer.resize(m_BytesPerSector + 2*(MXOledCount*picture_div_size + layouts_sys_div_size + 
		scancode_sys_div_size + order_sys_div_size) + version_sys_div_size - 1, 0x77);

	//Buffer addresses also should aligned to sector size
	BYTE* buffer_base = make_divisible(&m_Buffer.front(), m_BytesPerSector);

	//version.sys
	buffer_base = setFileParams(m_VersionSysFile, m_DeviceInfo.VDriveVolumeName + _T("vOptimus\\version.sys"), buffer_base, version_sys_div_size);
	m_FirmwareVersionString = readFirmwareVersionString();

	if (!m_FirmwareVersionString.IsEmpty())
	{
		//xxx.sys
		for (size_t ii = dfnFirstOledSys; ii <= dfnLastOledSys; ++ii)
		{
			TCHAR image_file_name[50] = {0};
			_stprintf(image_file_name, _T("vOptimus\\dynamic\\%03d.sys"), ii + 1);

			buffer_base = setFileParams(m_VirtualFiles[ii], m_DeviceInfo.VDriveVolumeName + image_file_name, buffer_base, picture_div_size);
		}

		//layout.sys
		buffer_base = setFileParams(m_VirtualFiles[dfnLayoutSys], m_DeviceInfo.VDriveVolumeName + _T("vOptimus\\layout.sys"), buffer_base, layouts_sys_div_size);

		//scancode.sys
		TCHAR scancode_sys_file_name[] = _T("vOptimus\\scancode.sys");
		if (canReadScancodeSys())
		{
			MXReadFile scancode_sys_read_file;
			setFileParams(scancode_sys_read_file, m_DeviceInfo.VDriveVolumeName + scancode_sys_file_name, buffer_base, scancode_sys_div_size);
			scancode_sys_read_file.ReadData();

			m_StaticScancodeSysData.resize(MXScancodeSysSize);
			memcpy(&m_StaticScancodeSysData.front(), buffer_base, MXScancodeSysSize);

			m_ScancodeSysData.resize(MXScancodeSysSize);
			memcpy(&m_ScancodeSysData.front(), buffer_base, MXScancodeSysSize);
		}
		else
		{
			memset(buffer_base, 0xFF, MXScancodeSysSize);
		}
		
		buffer_base = setFileParams(m_VirtualFiles[dfnScancodeSys], m_DeviceInfo.VDriveVolumeName + scancode_sys_file_name, buffer_base, scancode_sys_div_size);

		//order.sys
		setFileParams(m_VirtualFiles[dfnOrderSys], m_DeviceInfo.VDriveVolumeName + _T("vOptimus\\order.sys"), buffer_base, order_sys_div_size);

		res = true;
	}

	return res;
}

bool COptimusMaximus::connect()
{
	bool res = false;

	DeviceInfo::vector_t devices = MXDeviceEnumerator().EnumerateMaximuses();
	for (DeviceInfo::vector_t::const_iterator ii = devices.begin(); !res && ii != devices.end(); ++ii)
	{
		res = connect(*ii);
	}

	return res;
}

bool COptimusMaximus::connect(const DeviceInfo& device_info)
{
	bool res = false;

	if (!isConnected())
	{
		if (device_info.isComplete())
		{
			DWORD sectors_per_cluster   = 0;
			DWORD num_of_free_clusters  = 0;
			DWORD total_num_of_clusters = 0; 

			::GetDiskFreeSpace(device_info.VDriveVolumeName, &sectors_per_cluster, &m_BytesPerSector, &num_of_free_clusters, &total_num_of_clusters);

			if (m_BytesPerSector > 0)
			{
				m_DeviceInfo = device_info;

				if (initFiles())
				{					
					m_needDelayAfterWritingScancodeSys = needDelayAfterWritingScancodeSys();

					openHID();

					if (m_EventHandler)
					{
						m_EventHandler->OnConnect();
					}

					setAllKeysDynamic();

					res = true;
				}
				else
				{
					clearFiles();
				}
			}
		}
	}

	return res;
}

bool COptimusMaximus::isConnected() const
{
	return m_DeviceInfo.isComplete();
}

inline bool checkVolumeNameAlive(const CAtlString& volume_name)
{
	DWORD sectors_per_cluster   = 0;
	DWORD num_of_free_clusters  = 0;
	DWORD bytes_per_sector      = 0;
	DWORD total_num_of_clusters = 0; 

	return ::GetDiskFreeSpace(volume_name, &sectors_per_cluster, &bytes_per_sector, &num_of_free_clusters, &total_num_of_clusters) == TRUE;
}

bool COptimusMaximus::isAlive() const
{
	return isConnected() && checkVolumeNameAlive(m_DeviceInfo.VDriveVolumeName);
}

bool COptimusMaximus::unmountVDrive()
{
	bool res = false;

	if (isConnected())
	{
		if (m_DeviceInfo.VDriveLetter)
		{
			TCHAR drive_path[] = _T("A:\\");
			drive_path[0] = m_DeviceInfo.VDriveLetter;
			res = ::DeleteVolumeMountPoint(drive_path) == TRUE;
			m_DeviceInfo.VDriveLetter = res ? _T('\0') : m_DeviceInfo.VDriveLetter;
		}
	}

	return res;
}

bool COptimusMaximus::mountVDrive()
{
	bool res = false;

	if (isConnected())
	{
		if (!m_DeviceInfo.VDriveLetter)
		{
			TCHAR drive_path[] = _T("A:\\");
			for (TCHAR ii = _T('D'); ii <= _T('Z'); ++ii)
			{
				drive_path[0] = ii;
				res = ::SetVolumeMountPoint(drive_path, m_DeviceInfo.VDriveVolumeName) == TRUE;
				if (res)
				{
					m_DeviceInfo.VDriveLetter = ii;
					break;
				}
			}
		}
	}

	return res;
}

void COptimusMaximus::clearFiles()
{
	std::for_each(m_VirtualFiles, m_VirtualFiles + dfnFilesCount, std::mem_fun_ref(&MXAsynchronousWriteFile::Close));
	m_VersionSysFile.Close();
	m_Buffer.swap(buffer_t());

	m_FirmwareUpgradeBuffer.swap(buffer_t());
	m_StaticScancodeSysData.swap(buffer_t());
	m_ScancodeSysData.swap(buffer_t());

	m_DeviceInfo = DeviceInfo();
}

void COptimusMaximus::disconnect()
{
	if (isConnected())
	{
		closeHID();
		clearFiles();

		if (m_EventHandler)
		{
			m_EventHandler->OnDisconnect();
		}
	}

	m_needDelayAfterWritingScancodeSys = false;
}

void COptimusMaximus::setDefaultScancodeSys()
{
	if (isConnected())
	{
		if (!m_StaticScancodeSysData.empty())
		{
			writeFileData(dfnScancodeSys, &m_StaticScancodeSysData.front(), MXScancodeSysSize);
			m_ScancodeSysData = m_StaticScancodeSysData;
		}
	}
}

void COptimusMaximus::writeFileData(size_t file_index, const BYTE* data, size_t data_size)
{
	assert(file_index < dfnFilesCount);
	if (file_index < dfnFilesCount)
	{
		if (m_VirtualFiles[file_index].WriteData(data, DWORD(data_size)))
		{
			m_NeedUpdateEvent.Set();
		}
	}
}

bool COptimusMaximus::needRotateImage(size_t oled_index)
{
	return oled_index == 3 || oled_index == 14;
}

void COptimusMaximus::writeRGBImage(size_t key_id, BYTE* src_buff)
{
	if (isConnected())
	{
		const BYTE oled_index = g_KeyboardButtons[key_id].oledIndex;

		if (oled_index > 0)
		{
			BYTE dstbuf[MXOledPictureSize] = {0};
			if (needRotateImage(oled_index))
			{
				convertRGB2OLEDRotate(src_buff, dstbuf);
			}
			else
			{
				convertRGB2OLED(src_buff, dstbuf);
			}

			writeFileData(dfnFirstOledSys + oled_index - 1, dstbuf, MXOledPictureSize);
		}
	}
}

void COptimusMaximus::writeRGBAImage(size_t key_id, BYTE* src_buff)
{
	if (isConnected())
	{
		const BYTE oled_index = g_KeyboardButtons[key_id].oledIndex;

		if (oled_index > 0)
		{
			BYTE dstbuf[MXOledPictureSize] = {0};
			if (needRotateImage(oled_index))
			{
				convertRGBA2OLEDRotate(src_buff, dstbuf);
			}
			else
			{
				convertRGBA2OLED(src_buff, dstbuf);
			}

			writeFileData(dfnFirstOledSys + oled_index - 1, dstbuf, MXOledPictureSize);
		}
	}
}

bool COptimusMaximus::writeImage(size_t key_id, HBITMAP hbitmap)
{
	bool res = false;

	if (isConnected())
	{
		BITMAP bm = {0};
		if (::GetObject(hbitmap, sizeof(BITMAP), (LPVOID)&bm) && bm.bmHeight == MXKeyHeight && bm.bmWidth == MXKeyWidth)
		{
			if (bm.bmBitsPixel == 24)
			{
				writeRGBImage(key_id, (BYTE*)bm.bmBits);
				res = true;
			}
			else if (bm.bmBitsPixel == 32)
			{
				writeRGBAImage(key_id, (BYTE*)bm.bmBits);
				res = true;
			}
		}
	}

	return res;
}

bool COptimusMaximus::writeVirtualKey(size_t key_id, DWORD virtual_key)
{
	return virtual_key < MXVK2codeCount && g_vk2keycode[virtual_key] != 0 && writeActionCode(key_id,  g_vk2keycode[virtual_key]);
}

bool COptimusMaximus::writeActionCode(size_t key_id, MXActionCode action_code)
{
	bool res = false;

	if (isConnected())
	{
		BYTE* key_data = &m_ScancodeSysData.front() + (g_KeyboardButtons[key_id].keyIndex - 1)*MXScancodeSysBytesPerKey;
		memset(key_data, 0xFF, MXScancodeSysBytesPerKey);

		if (action_code != 0)
		{					
		  key_data[0] = akaStandartKey;
		  key_data[1] = action_code;
		}

		writeFileData(dfnScancodeSys, &m_ScancodeSysData.front(), MXScancodeSysSize);

		res = true;
	}

	return res;
}

bool COptimusMaximus::writeZeroActionCodes()
{
	bool res = false;

	if (isConnected())
	{
		memset(&m_ScancodeSysData.front(), 0xFF, MXScancodeSysSize);
		writeFileData(dfnScancodeSys, &m_ScancodeSysData.front(), MXScancodeSysSize);

		res = true;
	}

	return res;
}

bool COptimusMaximus::writeActionCodeSequence(size_t key_id, const MXActionCode* action_codes, size_t size)
{
	bool res = false;

	if (isConnected())
	{
		BYTE* key_data = &m_ScancodeSysData.front() + (g_KeyboardButtons[key_id].keyIndex - 1)*MXScancodeSysBytesPerKey;
		memset(key_data, 0xFF, MXScancodeSysBytesPerKey);

		const size_t actions_count = min(size, MXScancodeSysBytesPerKey/4);
		for (size_t ii = 0; ii < actions_count; ++ii)
		{
			key_data[ii*2]     = akaKeyMake;
			key_data[ii*2 + 1] = action_codes[ii];

			key_data[actions_count*2 + ii*2]     = akaKeyBrake;
			key_data[actions_count*2 + ii*2 + 1] = action_codes[ii];
		}

		writeFileData(dfnScancodeSys, &m_ScancodeSysData.front(), MXScancodeSysSize);

		res = true;
	}

	return res;
}

bool COptimusMaximus::writeVirtualKeySequence(size_t key_id, const DWORD* virtual_keys, size_t size)
{
	MXActionCode actions[MXScancodeSysBytesPerKey/4] = {0};

	const size_t actions_count = min(size, MXScancodeSysBytesPerKey/4);
	for (size_t ii = 0; ii < actions_count; ++ii)
	{
		actions[ii] = virtual_keys[ii] < MXVK2codeCount ? g_vk2keycode[virtual_keys[ii]] : 0;
	}

	return writeActionCodeSequence(key_id, actions, actions_count);
}

void COptimusMaximus::setAllKeysDynamic()
{
	if (isConnected())
	{
		BYTE buf[MXOledCount] = {0};
		memset(buf, 1, MXOledCount);

		writeFileData(dfnLayoutSys, buf, MXOledCount);
	}
}

void COptimusMaximus::setAllKeysStatic()
{
	if (isConnected())
	{
		BYTE buf[MXOledCount] = {0};

		writeFileData(dfnLayoutSys, buf, MXOledCount);
	}
}

DWORD WINAPI COptimusMaximus::ThreadProc(LPVOID ths)
{
	assert(ths);
	if (ths)
	{
		reinterpret_cast<COptimusMaximus*>(ths)->ThreadFunc();
	}

	return 0;
}

DWORD WINAPI COptimusMaximus::ThreadProcWithWindow(LPVOID ths)
{
	assert(ths);
	if (ths)
	{
		reinterpret_cast<COptimusMaximus*>(ths)->ThreadFuncWithWindow();
	}

	return 0;
}

void COptimusMaximus::FlushFilesBuffers()
{
	for (size_t ii = 0; ii < dfnFilesCount; ++ii)
	{
		const bool flush_res = m_VirtualFiles[ii].FlushBuffer();
		if (flush_res && (dfnScancodeSys == ii && m_needDelayAfterWritingScancodeSys))
		{
			::Sleep(300);
		}
	}

	FlushCommandsQueue();
}

COptimusMaximus::MXWmDeviceChangeResults COptimusMaximus::processWmDeviceChange(WPARAM wparam, LPARAM lparam)
{
	MXWmDeviceChangeResults res = wmdcNothing;

	if (lparam)
	{
		DEV_BROADCAST_HDR* broadcast_header = reinterpret_cast<DEV_BROADCAST_HDR*>(lparam);
		switch (wparam)
		{
			case DBT_DEVICEARRIVAL:
				if (broadcast_header->dbch_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
				{
					if (!isConnected())
					{
						res = connect() ? wmdcConnected : wmdcNothing;
					}
				}
			break;

			case DBT_DEVICEREMOVECOMPLETE:
				if (isConnected() && !isAlive())
				{
					disconnect();
					res = wmdcDisconnected;
				}
			break;
		}
	}

	return res;
}

LRESULT CALLBACK DeviceChangeWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_DEVICECHANGE)
	{
		COptimusMaximus* ths = reinterpret_cast<COptimusMaximus*>(::GetWindowLong(hWnd, GWL_USERDATA));
		if (ths != NULL)
		{
			ths->processWmDeviceChange(wParam, lParam);
		}
	}
	
	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}

HDEVNOTIFY COptimusMaximus::registerWmDeviceChange(HWND hWnd)
{
	DEV_BROADCAST_DEVICEINTERFACE filter = {0};
	filter.dbcc_size = sizeof(filter);
	filter.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
	filter.dbcc_classguid = GUID_DEVINTERFACE_VOLUME;

	return ::RegisterDeviceNotification(hWnd, &filter, DEVICE_NOTIFY_WINDOW_HANDLE); 
}

void COptimusMaximus::ThreadFuncWithWindow()
{	
	HWND hWnd = ::CreateWindow(_T("MESSAGE"), _T(""), 0, 0, 0, 0, 0, HWND_MESSAGE, NULL, NULL, NULL);
	::SetWindowLong(hWnd, GWL_WNDPROC,  (LONG)DeviceChangeWindowProc);
	::SetWindowLong(hWnd, GWL_USERDATA, (LONG)this);

	HDEVNOTIFY hNotify = registerWmDeviceChange(hWnd); 

	HANDLE hEvents[] = {m_StartReadHIDEvent, m_NeedUpdateEvent, m_ExitEvent};

	BYTE HID_buffer[MXInternalHIDReportSize] = {0};
	OVERLAPPED overlapped = {0};
	overlapped.hEvent = m_StartReadHIDEvent;
	
	for(;;)
	{		
		CONST DWORD dwRes = ::MsgWaitForMultipleObjects(sizeof(hEvents)/sizeof(HANDLE), hEvents, FALSE, INFINITE, QS_SENDMESSAGE | QS_ALLPOSTMESSAGE);

		if (dwRes == WAIT_OBJECT_0)
		{
			m_StartReadHIDEvent.Reset();
			readHIDReport(HID_buffer, &overlapped);			
		}
		else if (dwRes == WAIT_OBJECT_0 + 1)
		{
			m_NeedUpdateEvent.Reset();
			FlushFilesBuffers();
		}
		else if (dwRes == WAIT_OBJECT_0 + 2)
		{
			cancelHIDIo();
			break;
		}
		else if (dwRes == WAIT_OBJECT_0 + sizeof(hEvents)/sizeof(HANDLE))
		{
			MSG msg = {0}; 
			while (::PeekMessage(&msg, 0, 0, 0, PM_NOREMOVE)) 
			{ 	
				::DispatchMessage(&msg); 
			} 
		}
	}

	::UnregisterDeviceNotification(hNotify);
	::DestroyWindow(hWnd);
}

void COptimusMaximus::ThreadFunc()
{
	HANDLE hEvents[] = {m_StartReadHIDEvent, m_NeedUpdateEvent, m_ExitEvent};

	BYTE HID_buffer[MXInternalHIDReportSize] = {0};
	OVERLAPPED overlapped = {0};
	overlapped.hEvent = m_StartReadHIDEvent;

	for(;;)
	{
		CONST DWORD dwRes = ::WaitForMultipleObjects(sizeof(hEvents)/sizeof(HANDLE), hEvents, FALSE, INFINITE);
		if (dwRes == WAIT_OBJECT_0)
		{
			m_StartReadHIDEvent.Reset();			
			readHIDReport(HID_buffer, &overlapped);
		}
		else if (dwRes == WAIT_OBJECT_0 + 1)
		{
			m_NeedUpdateEvent.Reset();
			FlushFilesBuffers();
		}
		else if (dwRes == WAIT_OBJECT_0 + 2)
		{
			cancelHIDIo();
			break;
		}
	}
}

CAtlString COptimusMaximus::readFirmwareVersionString()
{
	CAtlString res;

	if (isConnected())
	{
		CHAR* version_str = reinterpret_cast<CHAR*>(m_VersionSysFile.ReadData());
		if (version_str != NULL)
		{
			res = CA2T(version_str);
		}
	}

	return res;
}

bool COptimusMaximus::canReadScancodeSys() const
{
	return !m_FirmwareVersionString.IsEmpty() && m_FirmwareVersionString >= L"OptimusV0.62b";
}

bool COptimusMaximus::needDelayAfterWritingScancodeSys() const
{	
	return !m_FirmwareVersionString.IsEmpty() && m_FirmwareVersionString < L"OptimusV0.76b";
}

bool COptimusMaximus::upgradeFirmware(BYTE* pBytes, DWORD cBytes)
{
	bool res = false;

	if (isConnected() && cBytes == MXUpgrateBinSize)
	{
		MXAsynchronousWriteFile& upgrade_bin_file = m_VirtualFiles[dfnUpgradeBin];
		assert(m_BytesPerSector > 0);
		if (m_BytesPerSector > 0)
		{
			const size_t upgrade_bin_div_size = make_divisible(MXUpgrateBinSize, m_BytesPerSector);
			m_FirmwareUpgradeBuffer.resize(2*upgrade_bin_div_size + m_BytesPerSector - 1);

			setFileParams(upgrade_bin_file, m_DeviceInfo.VDriveVolumeName + _T("vOptimus\\upgrade.bin"), 
				make_divisible(&m_FirmwareUpgradeBuffer.front(), m_BytesPerSector), upgrade_bin_div_size);
		}

		writeFileData(dfnUpgradeBin, pBytes, cBytes);
		res = true;	
	}	

	return res;
}

inline unsigned __int32 make_dword(BYTE* ip)
{
	return *ip + (*(ip+1) << 8) + (*(ip+2) << 16) + (*(ip+3) << 24);
}

bool COptimusMaximus::checkFirmwareChecksum(BYTE* pBytes, DWORD cBytes)
{
	bool res = false;

	enum
	{
		header_end_offset = 6,
		real_fimware_size_offset = 12,
		checksum_offset = real_fimware_size_offset + 4,
		firmware_offset = checksum_offset + 4
	};

	if (cBytes > firmware_offset)
	{
		if (memcmp(pBytes, "OM113_", header_end_offset) == 0)
		{
			DWORD real_firmware_size = make_dword(pBytes + real_fimware_size_offset); 
			if (real_firmware_size < cBytes)
			{
				unsigned __int32 read_checksum = make_dword(pBytes + checksum_offset);
				unsigned __int32 checksum = 0;

				for (BYTE* pb = pBytes + firmware_offset; pb < pBytes + firmware_offset + real_firmware_size; ++pb)
				{
					checksum += (*pb)^0xFF;
				}

				res = checksum == read_checksum;
			}
		}
	}

	return res;
}

bool COptimusMaximus::upgradeFirmware(LPCTSTR file_name)
{
	bool res = false;

	BYTE firmware_buffer[MXUpgrateBinSize] = {0};

	HANDLE handle = ::CreateFile(file_name, FILE_READ_DATA, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (handle != INVALID_HANDLE_VALUE)
	{
	    DWORD bytes_read = 0;
		if (::ReadFile(handle, firmware_buffer, sizeof(firmware_buffer)/sizeof(BYTE), &bytes_read, NULL) == TRUE)
		{
			if (checkFirmwareChecksum(firmware_buffer, bytes_read))
			{
				res = upgradeFirmware(firmware_buffer, bytes_read);
			}
		}

		::CloseHandle(handle);
	}

	return res;
}

void COptimusMaximus::writeOrderString(LPCSTR order)
{
	if (isConnected())
	{
		m_CommandsQueueLock.Enter();
		m_CommandsQueue.push_back(order);
		m_CommandsQueueLock.Leave();

		m_NeedUpdateEvent.Set();
	}
}

void COptimusMaximus::FlushCommandsQueue()
{	
	if (!m_CommandsQueue.empty())
	{
		m_CommandsQueueLock.Enter();
		commands_queue_t queue;
		queue.swap(m_CommandsQueue);
		m_CommandsQueueLock.Leave();

		MXAsynchronousWriteFile& order_sys = m_VirtualFiles[dfnOrderSys];
		for (commands_queue_t::const_iterator ii = queue.begin(); ii != queue.end(); ++ii)
		{
			order_sys.WriteData(ii->c_str(), ii->length() + 1);
			order_sys.FlushBuffer();
		}
	}
}

void COptimusMaximus::writeBrightness(unsigned int val, bool auto_mode)
{
	if (isConnected())
	{
		val = min(val, 100);

		char buff[25] = {0};
		sprintf(buff, auto_mode ? "b%03dA" : "b%03d", val);
		writeOrderString(buff);
	}
}

void COptimusMaximus::writeSleepModeDelay(unsigned int val)
{
	if (isConnected())
	{
		val = min(val, 9999);

		char buff[25] = {0};
		sprintf(buff, "s%04d", val);
		writeOrderString(buff);
	}
}

void COptimusMaximus::openHID()
{
	if (!m_DeviceInfo.InternalHidEndpointDevicePath.IsEmpty())
	{
		memset(m_PrevHIDReport, 0, MXInternalHIDReportSize);

		HANDLE hid_handle = ::CreateFile(m_DeviceInfo.InternalHidEndpointDevicePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
			OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);

		m_InternalHID = ATL::CHandle(hid_handle != INVALID_HANDLE_VALUE ? hid_handle : NULL);
		assert(m_InternalHID);
		if (m_InternalHID)
		{
			m_StartReadHIDEvent.Set();
		}
	}
}

void COptimusMaximus::closeHID()
{
	BYTE zero_report[MXInternalHIDReportSize] = {0};
	processHIDReport(zero_report);

	m_InternalHID = ATL::CHandle();
}

void COptimusMaximus::readHIDReport(BYTE* buffer, LPOVERLAPPED overlapped)
{
	if (m_InternalHID)
	{
		DWORD bytes_readed = 0;
		// First call after open occurs on invalid overlapped structure
		if (::GetOverlappedResult(m_InternalHID, overlapped, &bytes_readed, FALSE))
		{			
			if (bytes_readed == MXInternalHIDReportSize)
			{				
				processHIDReport(buffer);
			}
		}

		while (::ReadFile(m_InternalHID, buffer, MXInternalHIDReportSize, &bytes_readed, overlapped))
		{
			if (bytes_readed == MXInternalHIDReportSize)
			{				
				processHIDReport(buffer);
			}
		}
	}
}

void COptimusMaximus::cancelHIDIo()
{
	if (m_InternalHID)
	{
		::CancelIo(m_InternalHID);
	}
}

void COptimusMaximus::processHIDReport(BYTE* curr_report)
{
	if (m_EventHandler)
	{
		// In first byte Windows sends report id
		if (m_PrevHIDReport[0] == 0)
		{
			for (size_t ii = 1; ii < MXInternalHIDReportSize; ++ii)
			{
				CONST BYTE prev_byte = m_PrevHIDReport[ii];
				CONST BYTE curr_byte = curr_report[ii];

				m_PrevHIDReport[ii]  = curr_report[ii];

				CONST BYTE down_mask = (curr_byte & (~prev_byte));
				if (down_mask)
				{			
					for (size_t jj = 0; jj < 8; ++jj)
					{
						if (down_mask & (1 << jj))
						{
							m_EventHandler->OnKeyDown((ii - 1)*8 + jj);
						}
					}
				}

				CONST BYTE up_mask = (prev_byte & (~curr_byte));
				if (up_mask)
				{				
					for (size_t jj = 0; jj < 8; ++jj)
					{
						if (up_mask & (1 << jj))
						{
							m_EventHandler->OnKeyUp((ii - 1)*8 + jj);
						}
					}			
				}			
			}
		}
	}
}
