#ifndef OPTIMUS_MAXIMUS_H
#define OPTIMUS_MAXIMUS_H

#include "MaximusDefaults.h"

#include <vector>

#include <atlsync.h>
#include <atlstr.h>

#include "MXDeviceEnumerator.h" // Maximus device search support
#include "MXButtons.h"			// Maximus uses it's own key numbering, thus translation table required
#include "MXFiles.h"			// Support for buffered button image files

class COptimusMaximus
{
public:
	typedef MXDeviceEnumerator::DeviceInfo DeviceInfo;

public:
	/* register keyboard event handler interface with setEventHandler to process keyboard events */
	class IEventHandler
	{
	public:
		virtual void OnConnect() = 0;
		virtual void OnDisconnect() = 0;

		/* Since 076b version Maximus has internal HID device, which sends KeyDown/KeyUp events */
		/* There is no autorepeat, use g_KeyboardButtons[key_id].winVK to get button default Windows Virtual Key code */
		/* Note: key_id is a button number, it does not change even if the button is programmed to send another code */
		virtual void OnKeyDown(size_t key_id) = 0;
		virtual void OnKeyUp(size_t key_id) = 0;
	};

	enum MXConstans
	{
		MXOledCount = 114,
		MXInternalHIDReportSize = 16,
		MXSleepModeDelayInfinite = 9999
	};

	/* returned by processWmDeviceChange method */
	enum MXWmDeviceChangeResults
	{
		wmdcNothing = 0,
		wmdcConnected,
		wmdcDisconnected
	};

/* ******************************************* public interface begin ***************************************** */

public:
	/* thread for asynchronous I/O operations is created */
	/* setEventHandler and connect methods should be called after constructor */
	COptimusMaximus(bool use_internal_window_for_event_handling = true);
	~COptimusMaximus();

public:
	/* connects to the first available Maximus device and switches all keys to display dynamic images */
	bool connect();
	/* connects to the specified Maximus device */
	bool connect(const DeviceInfo&);

	/* register before connect() to receive keyboard events */
	void setEventHandler(IEventHandler* event_handler){m_EventHandler = event_handler;}

	/* If you don't use Maximus library internal window feature by passing false to constructor, you need to either */
	/* call registerWmDeviceChange with your window handle or call processWmDeviceChange when WM_DEVICECHANGE event arises */
	HDEVNOTIFY registerWmDeviceChange(HWND);
	MXWmDeviceChangeResults processWmDeviceChange(WPARAM, LPARAM);

	bool  isConnected() const;
	/* true if Maximus is connected and virtual disk responses to requests */
	bool  isAlive() const;
	const DeviceInfo& getDeviceInfo() const {return m_DeviceInfo;}

	/* To remove and restore Drive letter assignment for Maximus virtual disk */
	bool unmountVDrive();
	bool mountVDrive();

	/* Displays an image on specified button. This functions are not blocking, */
	/* as all I/O operations are done asynchronously from another thread */
	bool writeImage(size_t key_id, HBITMAP);
	void writeRGBImage(size_t key_id, BYTE*);
	/* RGBA format is supported, but alpha channel data is ignored */
	void writeRGBAImage(size_t key_id, BYTE*);

	/* Programms the specified button to send another code */
	/* using Windows Virtual Key code */
	bool writeVirtualKey(size_t key_id, DWORD virtual_key);
	/* using keyboard chip action code, listed in g_KeyInfo array in MXKeyCode.h */
	/* specify zero value to disable button action */
	bool writeActionCode(size_t key_id, MXActionCode action_code);
	/* disable actions for all buttons, to work with keyboard using only internal HID events */
	bool writeZeroActionCodes();

	bool writeActionCodeSequence(size_t key_id, const MXActionCode* action_codes, size_t size);
	bool writeVirtualKeySequence(size_t key_id, const DWORD* virtual_keys, size_t size);

	/* Firmware upgrade support functions */
	const CAtlString& getFirmwareVersionString() const {return m_FirmwareVersionString;}
	static bool checkFirmwareChecksum(BYTE* pBytes, DWORD cBytes);
	bool upgradeFirmware(BYTE* pBytes, DWORD cBytes);
	bool upgradeFirmware(LPCTSTR file_name);
	
	/* Changes OLED brightness. Brightness value ranges from 0 to 100, default 70 */
	/* Auto mode enables brightness control by firmware using build-in ambient censor */
	void writeBrightness(unsigned int val, bool auto_mode);
	/* Sleep mode used to increase OLEDs lifetime. Sleep delay value measured in seconds, default 180 */
	/* Use 0 to switch Maximus to sleep mode immediately, MXSleepModeDelayInfinite value to disable sleep mode */
	void writeSleepModeDelay(unsigned int val);
		
	bool isHIDOpened() const {return m_InternalHID != NULL;}
	bool isKeyPressed(size_t key_id) const {return (getHIDReportByte(key_id / 8 + 1) & (1 << (key_id % 8))) > 0;}
	/* HID report keeps bit mask of presses buttons, one bit for each key */
	CONST BYTE* getHIDReport() const {return m_PrevHIDReport;}
	BYTE getHIDReportByte(size_t byte_index) const {return byte_index < MXInternalHIDReportSize ? m_PrevHIDReport[byte_index] : 0;}

/* ******************************************** public interface end ****************************************** */
protected:
	enum MXFilesizeConstants
	{
		MXOledPictureSize        = MXKeySquare*2,
		MXLayoutSysSize          = MXOledCount,
		MXScancodeSysBytesPerKey = 64,
		MXScancodeSysSize        = MXScancodeSysBytesPerKey*144,
		MXUpgrateBinSize         = 655360,
		MXOrderSysSize           = 5,

		MXVersionSysSize         = 27
	};

	enum MXFileNum
	{
		dfnFirstOledSys = 0,
		dfnLastOledSys  = MXOledCount - 1,
		dfnScancodeSys,
		dfnOrderSys,
		dfnLayoutSys,
		dfnUpgradeBin,		
		dfnFilesCount
	};

	enum MXActionKeyAction
	{
		akaStandartKey = 1,
		akaKeyMake     = 2,
		akaKeyBrake    = 4
	};

protected:
	COptimusMaximus(const COptimusMaximus&);

	void writeFileData(size_t file_index, const BYTE* data, size_t data_size);
	
	void setAllKeysDynamic();
	void setAllKeysStatic();
	void setDefaultScancodeSys();

protected:
	static void convertRGB2OLED(CONST BYTE* srcbuf, BYTE* dstbuf);
	static void convertRGB2OLEDRotate(CONST BYTE* srcbuf, BYTE* dstbuf);

	static void convertRGBA2OLED(CONST BYTE* srcbuf, BYTE* dstbuf);
	static void convertRGBA2OLEDRotate(CONST BYTE* srcbuf, BYTE* dstbuf);

	static bool needRotateImage(size_t key_id);

private:
	static DWORD WINAPI ThreadProc(LPVOID ths);
	static DWORD WINAPI ThreadProcWithWindow(LPVOID ths);
	void ThreadFunc();
	void ThreadFuncWithWindow();
	void FlushFilesBuffers();
	void FlushCommandsQueue();

	CAtlString readFirmwareVersionString();
	bool canReadScancodeSys() const;
	bool needDelayAfterWritingScancodeSys() const;

	bool initFiles();	
	void clearFiles();
	void writeOrderString(LPCSTR order);

	void openHID();
	void closeHID();
	void readHIDReport(BYTE*, LPOVERLAPPED overlapped);
	void cancelHIDIo();
	void processHIDReport(BYTE*);
	
	void disconnect();

protected:
	typedef std::vector<BYTE> buffer_t;
	typedef std::vector<std::string> commands_queue_t;

	DeviceInfo m_DeviceInfo;
	DWORD m_BytesPerSector;

	MXAsynchronousWriteFile m_VirtualFiles[dfnFilesCount];
	buffer_t m_Buffer;
	buffer_t m_FirmwareUpgradeBuffer;
	
	ATL::CHandle m_Thread;
	ATL::CEvent  m_NeedUpdateEvent;
	ATL::CEvent  m_ExitEvent;

	MXReadFile m_VersionSysFile;
	CAtlString m_FirmwareVersionString;

	buffer_t m_StaticScancodeSysData;
	buffer_t m_ScancodeSysData;

	ATL::CHandle m_InternalHID;
	ATL::CEvent  m_StartReadHIDEvent;
	BYTE m_PrevHIDReport[MXInternalHIDReportSize];

	IEventHandler* m_EventHandler;

	bool m_needDelayAfterWritingScancodeSys;

	ATL::CCriticalSection m_CommandsQueueLock;
	commands_queue_t      m_CommandsQueue;
};

#endif OPTIMUS_MAXIMUS_H

