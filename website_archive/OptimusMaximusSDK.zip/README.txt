MaximusLibrary.sln - Visual Studio 2005 solution
MaximusLibrary2003.sln - Visual Studio 2003 solution (without COM)

MaximusLibrary - C++ Library, see OptimusMaximus.h for interface description
MaximusLibraryUsageExample - C++ usage example plus simple Snake and Memory games

MaximusCOM - COM wrapper for MaximusLibrary
MaximusCOMUsageExample - COM wrapper C# usage example

release - compiled binaries for all examples and games 
          (Visual C++ runtime required and COM should be registered with registerCOM.cmd)
