// DeviceInfo.cpp : Implementation of CDeviceInfo

#include "stdafx.h"
#include "DeviceInfo.h"

// CDeviceInfo

STDMETHODIMP CDeviceInfo::get_VDriveLetter(OLECHAR* pVal)
{
	*pVal = m_Info.VDriveLetter;

	return S_OK;
}

STDMETHODIMP CDeviceInfo::get_VDriveVolumeName(BSTR* pVal)
{
	*pVal = m_Info.VDriveVolumeName.AllocSysString();

	return S_OK;
}

STDMETHODIMP CDeviceInfo::get_VDriveDevicePath(BSTR* pVal)
{
	*pVal = m_Info.VDriveDevicePath.AllocSysString();
	
	return S_OK;
}

STDMETHODIMP CDeviceInfo::get_MultimediaHidEndpointDevicePath(BSTR* pVal)
{
	*pVal = m_Info.MultimediaHidEndpointDevicePath.AllocSysString();

	return S_OK;
}

STDMETHODIMP CDeviceInfo::get_InternalHidEndpointDevicePath(BSTR* pVal)
{
	*pVal = m_Info.InternalHidEndpointDevicePath.AllocSysString();

	return S_OK;
}
