// DeviceInfo.h : Declaration of the CDeviceInfo

#pragma once
#include "resource.h"       // main symbols

#include "MaximusCOM.h"

#include "ATLUtils.h"

#include "..\MaximusLibrary\MXDeviceEnumerator.h" //4 DeviceInfo

// CDeviceInfo

class ATL_NO_VTABLE CDeviceInfo :
	public ATLTypes<CDeviceInfo>,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDeviceInfo, &CLSID_DeviceInfo>,
	public IDispatchImpl<IDeviceInfo, &IID_IDeviceInfo, &LIBID_MaximusCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
private:
	MXDeviceEnumerator::DeviceInfo m_Info;

public:
	CDeviceInfo()
	{
	}

	void SetInfo(const MXDeviceEnumerator::DeviceInfo& info){m_Info = info;}

BEGIN_COM_MAP(CDeviceInfo)
	COM_INTERFACE_ENTRY(IDeviceInfo)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:
	STDMETHOD(get_VDriveLetter)(OLECHAR* pVal);
	STDMETHOD(get_VDriveVolumeName)(BSTR* pVal);
	STDMETHOD(get_VDriveDevicePath)(BSTR* pVal);
	STDMETHOD(get_MultimediaHidEndpointDevicePath)(BSTR* pVal);
	STDMETHOD(get_InternalHidEndpointDevicePath)(BSTR* pVal);
};
