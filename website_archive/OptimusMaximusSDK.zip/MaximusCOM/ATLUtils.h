#ifndef ATL_UTILS_H_5b0462a2b10f4054bdda101fa0c60210
#define ATL_UTILS_H_5b0462a2b10f4054bdda101fa0c60210

#include <vector>

#include <atlbase.h>
#include <atlcom.h>

using namespace ATL;

template <class T>
class ATLTypes
{
public:
	typedef ATL::CComObject<T>  obj_t;
	typedef ATL::CComPtr<obj_t> ptr_t;
	typedef std::vector<ptr_t>  vector_t;

	template <class T>
	struct CopyAdaptToVariant 
	{
		static void init   (VARIANT* v) {VariantInit(v); }
		static void destroy(VARIANT* v) {VariantClear(v);}
		template <class TT>
		static HRESULT copy(VARIANT *v, const CComPtr<TT> *ptr)
		{
			HRESULT hr = ptr->QueryInterface(&v->pdispVal);
			if (SUCCEEDED(hr)) 
			{
				v->vt = VT_DISPATCH;
			}
			else 
			{
				hr = ptr->QueryInterface(&v->punkVal);
				if(SUCCEEDED(hr))
				{
					v->vt = VT_UNKNOWN;
				}
			}
			return hr;
		}
	};

	template <class T>
	struct CopyAdaptToItf 
	{
		static void init   (T** p){}
		static void destroy(T** p){if (*p) (*p)->Release();}
		template <class TT>
		static HRESULT copy(T** p1, const CComPtr<TT>* p2) 
		{
			return (*p2)->QueryInterface(p1);
		}
	};

	template <class ICT, class TI, class SCT = vector_t>
	class ATL_NO_VTABLE IDispatchCollectionImpl:
		public ICollectionOnSTLImpl<
			IDispatchImpl<ICT,&__uuidof(ICT)>,
			SCT,
			TI*,
			CopyAdaptToItf<TI>,
			CComEnumOnSTL<
				IEnumVARIANT, &IID_IEnumVARIANT, VARIANT,
				CopyAdaptToVariant<TI>,
				SCT
			> >
	{};

	template <class ICT, class TI, class SCT = vector_t>
	class ATL_NO_VTABLE com_collection_t :
		public ATLTypes<com_collection_t<ICT, TI, SCT> >,
		public CComObjectRootEx<CComSingleThreadModel>,
		public CComCoClass<com_collection_t<ICT, TI, SCT> >,
		public IDispatchCollectionImpl<ICT, TI, SCT>
	{
	public:
	BEGIN_COM_MAP(com_collection_t)
		COM_INTERFACE_ENTRY(ICT)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()

		DECLARE_PROTECT_FINAL_CONSTRUCT()

		HRESULT FinalConstruct(){return S_OK;}
		void FinalRelease(){}
	};
};

#endif //ATL_UTILS_H_5b0462a2b10f4054bdda101fa0c60210