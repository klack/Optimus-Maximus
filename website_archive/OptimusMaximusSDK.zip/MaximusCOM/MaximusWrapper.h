#ifndef MAXIMUS_WRAPPER_H_
#define MAXIMUS_WRAPPER_H_

#include <atlcom.h>

#include "MXPtr.h"
#include "..\MaximusLibrary\OptimusMaximus.h"

class CMaximusWrapper
{
protected:
	typedef MXPtr<COptimusMaximus> maximus_ptr_t;

protected:
	CMaximusWrapper(const CLSID& clsid):m_ErrorsClassID(clsid){}
	~CMaximusWrapper();

protected:
	void SetMaximus(maximus_ptr_t maximus) {m_Maximus = maximus;}

	HRESULT GetInited() const;
	HRESULT GetState() const;
	HRESULT CheckParam(ULONG key_index) const;

	HRESULT Connect();
	HRESULT get_Connected(VARIANT_BOOL* pVal);
	HRESULT get_Alive(VARIANT_BOOL* pVal);

	HRESULT WriteHBITMAP(ULONG key_index, HBITMAP hbitmap);
	HRESULT WriteImageFromFile(ULONG key_index, BSTR file_path);
	HRESULT WriteImageFromHbitmap(ULONG key_index, OLE_HANDLE hbitmap);
	HRESULT WriteImageFromHbitmapAndDeleteObject(ULONG key_index, OLE_HANDLE hbitmap);
	HRESULT WriteIPictureDisp(ULONG key_index, IPictureDisp* picture);

	HRESULT WriteKeyActionByVirtualKey(ULONG key_index, USHORT virtual_key);

	HRESULT UnmountVDrive();
	HRESULT MountVDrive();

	HRESULT get_FirmwareVersion(BSTR* pVal);
	HRESULT UpgradeFirmwareFromFile(BSTR file_path);
	HRESULT UpgradeFirmwareFromBuffer(BYTE* buffer, ULONG buffer_size);

	HRESULT WriteSleepModeDelay(ULONG delay);
	HRESULT WriteBrightness(ULONG brightness, VARIANT_BOOL auto_mode);

	HRESULT get_HIDReportByte(USHORT byte_index, BYTE* pVal);

private:
	HRESULT Error(LPCSTR lpszDesc) const;

protected:
	maximus_ptr_t m_Maximus;

private:
	CLSID m_ErrorsClassID;
};

#endif //CMaximusWrapper
