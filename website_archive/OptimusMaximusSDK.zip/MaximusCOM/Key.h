// Key.h : Declaration of the CKey

#pragma once
#include "resource.h"       // main symbols

#include "MaximusCOM.h"

#include "ATLUtils.h"
#include "MaximusWrapper.h"

#include "KeyDefaults.h"

// CKey

class ATL_NO_VTABLE CKey :
	public ATLTypes<CKey>,
	public CMaximusWrapper,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CKey, &CLSID_Key>,
	public ISupportErrorInfoImpl<&IID_IKey>,
	public IDispatchImpl<IKey, &IID_IKey, &LIBID_MaximusCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
private:
	ULONG m_KeyIndex;

	CKeyDefaults::ptr_t m_KeyDefaults;

public:
	CKey():CMaximusWrapper(GetObjectCLSID()), m_KeyIndex(MXKeyCount)
	{
	}

	using CMaximusWrapper::SetMaximus;
	void SetKeyIndex(ULONG key_index) {m_KeyIndex = key_index;}

BEGIN_COM_MAP(CKey)
	COM_INTERFACE_ENTRY(IKey)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:
	STDMETHOD(WriteActionByVirtualKey)(USHORT virtual_key);
	STDMETHOD(WriteImageFromHbitmap)(OLE_HANDLE hbitmap);
	STDMETHOD(WriteImageFromHbitmapAndDeleteObject)(OLE_HANDLE hbitmap);
	STDMETHOD(WriteIPictureDisp)(IPictureDisp *picture);
	STDMETHOD(get_Defaults)(IKeyDefaults** pVal);
};