#ifndef OPT_HANDLER_H
#define OPT_HANDLER_H

#include <assert.h>

template <class T>
class MXPtr
{
public:
	typedef T value_type;

	MXPtr():m_Ref(NULL),m_Instance(NULL){}
	MXPtr(T* instance):m_Instance(instance)
	{
		m_Ref = instance ? new size_t(1) : NULL;		
	}

	MXPtr(const MXPtr& other)
	{
		other.AddRef();
		m_Ref = other.m_Ref;
		m_Instance = other.m_Instance;
	}

	template <class DT>
	MXPtr(const MXPtr<DT>& other)
	{
		other.AddRef();
		m_Ref = other.m_Ref;
		m_Instance = other.m_Instance;
	}

	~MXPtr()
	{
		Release();
	}

	MXPtr<T>& operator=(const MXPtr<T>& other)
	{
		other.AddRef();
		Release();
		m_Ref = other.m_Ref;
		m_Instance = other.m_Instance;
		return *this;
	}

	template <class DT>
	MXPtr<T>& operator=(const MXPtr<DT>& other)
	{
		other.AddRef();
		Release();
		m_Ref = other.m_Ref;
		m_Instance = other.m_Instance;
		return *this;
	}

	T* operator->() const
	{		
		assert(MXPtr<T>::IsValid());
		return Get();
	}

	T& operator*() const
	{
		assert(MXPtr<T>::IsValid());
		return *Get();
	}

	T* Get() const
	{
		return m_Instance;
	}

	bool IsValid() const
	{
		return m_Ref && m_Instance && (*m_Ref);
	}

	size_t GetCounter() const
	{
		return m_Ref != NULL ? *m_Ref : 0;
	}

	bool operator==(const T* other) const
	{
		return m_Ref != NULL ? m_Instance == other : other == NULL;
	}

	template <class DT>
	bool operator==(const MXPtr<DT>& other) const
	{
		return m_Ref == other.m_Ref || (!IsValid() && !other.IsValid());
	}

	bool operator!=(const T* other) const
	{
		return !(*this == other);		
	}

	template <class DT>
	bool operator!=(const MXPtr<DT>& other) const
	{
		return !(*this == other);
	}

	template <class DT>
	bool operator<(const DT* other) const
	{
		return Get() < other;		
	}

	template <class DT>
	bool operator<(const MXPtr<DT>& other) const
	{
		return Get() < other.Get();
	}

	bool operator!() const
	{
		return !Get();
	}

	MXPtr<T> Clone() const
	{
		return IsValid() ? new T(**this) : MXPtr<T>();
	}

private:
	template <class T>
	class MXPtrDynamiCastHelper
	{
	public:
		MXPtrDynamiCastHelper(const MXPtr<T>& val):m_Val(val){}

		template <class TD>
		operator MXPtr<TD>() const
		{
			MXPtr<TD> res;
			TD* dynamic_pointer = dynamic_cast<TD*>(m_Val.m_Instance);

			if (dynamic_pointer != NULL)
			{
				m_Val.AddRef();
				res.m_Ref = m_Val.m_Ref;
				res.m_Instance = dynamic_pointer;
			}

			return res;
		}

	private:
		const MXPtr<T>& m_Val;
	};

public:
	MXPtrDynamiCastHelper<T> dcast() const
	{
		return MXPtrDynamiCastHelper<T>(*this);
	}

    template<class DT> friend class MXPtr;
    template<class DT> friend class MXPtrDynamiCastHelper;

private:
	void AddRef() const
	{
		if (m_Ref)
			(*m_Ref)++;
	}

	void Release()
	{
		if (m_Ref && !--(*m_Ref))
		{
			delete m_Instance;
			m_Instance = NULL;

			delete m_Ref;
			m_Ref = NULL;
		}
	}

private:
	size_t* m_Ref;
	T* m_Instance;
};

template <class DT, class T>
bool operator<(const DT* a, const MXPtr<T>& b)
{
	return a < b.Get();		
}

#endif //OPT_HANDLER_H