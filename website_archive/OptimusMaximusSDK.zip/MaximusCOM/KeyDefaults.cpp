// KeyDefaults.cpp : Implementation of CKeyDefaults

#include "stdafx.h"
#include "KeyDefaults.h"

#include "..\MaximusLibrary\MXButtons.h"

// CKeyDefaults

STDMETHODIMP CKeyDefaults::get_Name(BSTR* pVal)
{
	*pVal = CString(g_KeyboardButtons[m_KeyIndex].keyName).AllocSysString();

	return S_OK;
}

STDMETHODIMP CKeyDefaults::get_DisplayName(BSTR* pVal)
{
	*pVal = CString(g_KeyboardButtons[m_KeyIndex].keyDisplayName).AllocSysString();

	return S_OK;
}

STDMETHODIMP CKeyDefaults::get_VirtualKey(USHORT* pVal)
{
	*pVal = g_KeyboardButtons[m_KeyIndex].winVK;

	return S_OK;
}

STDMETHODIMP CKeyDefaults::get_ActionCode(USHORT* pVal)
{
	*pVal = g_KeyboardButtons[m_KeyIndex].actionCode;

	return S_OK;
}
