// Key.cpp : Implementation of CKey

#include "stdafx.h"
#include "Key.h"

// CKey

STDMETHODIMP CKey::WriteActionByVirtualKey(USHORT virtual_key)
{
	return CMaximusWrapper::WriteKeyActionByVirtualKey(m_KeyIndex, virtual_key);
}

STDMETHODIMP CKey::WriteImageFromHbitmap(OLE_HANDLE hbitmap)
{
	return CMaximusWrapper::WriteImageFromHbitmap(m_KeyIndex, hbitmap);
}

STDMETHODIMP CKey::WriteImageFromHbitmapAndDeleteObject(OLE_HANDLE hbitmap)
{
	return CMaximusWrapper::WriteImageFromHbitmapAndDeleteObject(m_KeyIndex, hbitmap);
}

STDMETHODIMP CKey::WriteIPictureDisp(IPictureDisp *picture)
{
	return CMaximusWrapper::WriteIPictureDisp(m_KeyIndex, picture);
}

STDMETHODIMP CKey::get_Defaults(IKeyDefaults** pVal)
{
	HRESULT hr = S_OK;

	if (m_KeyDefaults == NULL)
	{
		hr = CKeyDefaults::obj_t::CreateInstance(&m_KeyDefaults);
		if (SUCCEEDED(hr))
		{
			m_KeyDefaults->InternalAddRef();
			m_KeyDefaults->SetKeyIndex(m_KeyIndex);
		}
	}

	if (SUCCEEDED(hr))
	{
		hr = m_KeyDefaults->QueryInterface(pVal);
	}

	return hr;
}
