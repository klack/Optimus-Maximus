// Keyboard.cpp : Implementation of CKeyboard

#include "stdafx.h"
#include "Keyboard.h"

#include "DeviceInfo.h"

// CKeyboard

CKeyboard::CKeyboard():CMaximusWrapper(GetObjectCLSID())
{
	m_Maximus = new COptimusMaximus();
	m_Maximus->setEventHandler(this);
}

CKeyboard::~CKeyboard()
{
	if (m_Maximus != NULL)
	{
		m_Maximus->setEventHandler(NULL);
	}
}

void CKeyboard::OnConnect()
{
	Fire_OnConnect();
}

void CKeyboard::OnDisconnect()
{
	Fire_OnDisconnect();
}

STDMETHODIMP CKeyboard::Connect(void)
{
	return CMaximusWrapper::Connect();
}

STDMETHODIMP CKeyboard::get_Connected(VARIANT_BOOL* pVal)
{
	return CMaximusWrapper::get_Connected(pVal);
}

STDMETHODIMP CKeyboard::WriteImageFromFile(ULONG key_index, BSTR file_path)
{
	return CMaximusWrapper::WriteImageFromFile(key_index, file_path);
}

STDMETHODIMP CKeyboard::WriteImageFromHbitmap(ULONG key_index, OLE_HANDLE hbitmap)
{
	return CMaximusWrapper::WriteImageFromHbitmap(key_index, hbitmap);
}

STDMETHODIMP CKeyboard::WriteImageFromHbitmapAndDeleteObject(ULONG key_index, OLE_HANDLE hbitmap)
{
	return CMaximusWrapper::WriteImageFromHbitmapAndDeleteObject(key_index, hbitmap);
}

STDMETHODIMP CKeyboard::WriteIPictureDisp(ULONG key_index, IPictureDisp* picture)
{
	return CMaximusWrapper::WriteIPictureDisp(key_index, picture);
}

STDMETHODIMP CKeyboard::WriteKeyActionByVirtualKey(ULONG key_index, USHORT virtual_key)
{
	return CMaximusWrapper::WriteKeyActionByVirtualKey(key_index, virtual_key);
}

STDMETHODIMP CKeyboard::UnmountVDrive(void)
{
	return CMaximusWrapper::UnmountVDrive();
}

STDMETHODIMP CKeyboard::MountVDrive(void)
{
	return CMaximusWrapper::MountVDrive();
}

STDMETHODIMP CKeyboard::UpgradeFirmwareFromFile(BSTR file_path)
{
	return CMaximusWrapper::UpgradeFirmwareFromFile(file_path);
}

STDMETHODIMP CKeyboard::UpgradeFirmwareFromBuffer(BYTE* buffer, ULONG buffer_size)
{
	return CMaximusWrapper::UpgradeFirmwareFromBuffer(buffer, buffer_size);
}

STDMETHODIMP CKeyboard::get_DeviceInfo(IDeviceInfo** pVal)
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		CDeviceInfo::ptr_t device_info;
		hr = CDeviceInfo::obj_t::CreateInstance(&device_info);
		if (SUCCEEDED(hr))
		{
			device_info->InternalAddRef();
			device_info->SetInfo(m_Maximus->getDeviceInfo());
			hr = device_info->QueryInterface(pVal);
		}
	}

	return hr;
}

STDMETHODIMP CKeyboard::get_Keys(IKeys** pVal)
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		typedef ATLTypes<IKey>::com_collection_t<IKeys, IKey, ikey_vector_t> collection_t;
		collection_t::ptr_t keys;

		hr = collection_t::obj_t::CreateInstance(&keys);
		if (SUCCEEDED(hr))
		{
			keys->InternalAddRef();		

			if (m_Keys.empty())
			{
				m_Keys.reserve(MXKeyCount);
				for (size_t ii = 0; ii < MXKeyCount; ++ii)
				{
					CKey::ptr_t key;
					HRESULT hr = CKey::obj_t::CreateInstance(&key);
					if (SUCCEEDED(hr))
					{
						key->InternalAddRef();

						key->SetMaximus(m_Maximus);
						key->SetKeyIndex(ii);

						m_Keys.push_back(CComQIPtr<IKey>(key));
					}
					else
					{
						break;
					}
				}
			}

			keys->m_coll = m_Keys;

			hr = keys->QueryInterface(pVal);
		}
	}

	return hr;
}

STDMETHODIMP CKeyboard::get_Alive(VARIANT_BOOL* pVal)
{
	return CMaximusWrapper::get_Alive(pVal);
}

STDMETHODIMP CKeyboard::get_FirmwareVersion(BSTR* pVal)
{
	return CMaximusWrapper::get_FirmwareVersion(pVal);
}

void CKeyboard::OnKeyDown(size_t key_id)
{
	Fire_OnKeyDown(key_id);
}

void CKeyboard::OnKeyUp(size_t key_id)
{
	Fire_OnKeyUp(key_id);
}

STDMETHODIMP CKeyboard::WriteSleepModeDelay(ULONG delay)
{
	return CMaximusWrapper::WriteSleepModeDelay(delay);
}

STDMETHODIMP CKeyboard::WriteBrightness(ULONG brightness, VARIANT_BOOL auto_mode)
{
	return CMaximusWrapper::WriteBrightness(brightness, auto_mode);
}

STDMETHODIMP CKeyboard::get_HIDReportByte(USHORT byte_index, BYTE* pVal)
{
	return CMaximusWrapper::get_HIDReportByte(byte_index, pVal);
}
