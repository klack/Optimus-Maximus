// KeyDefaults.h : Declaration of the CKeyDefaults

#pragma once
#include "resource.h"       // main symbols

#include "ATLUtils.h"
#include "MaximusCOM.h"

// CKeyDefaults

class ATL_NO_VTABLE CKeyDefaults :
	public ATLTypes<CKeyDefaults>,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CKeyDefaults, &CLSID_KeyDefaults>,
	public IDispatchImpl<IKeyDefaults, &IID_IKeyDefaults, &LIBID_MaximusCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
private:
	ULONG m_KeyIndex;

public:
	CKeyDefaults():m_KeyIndex(MXKeyCount)
	{
	}

	void SetKeyIndex(ULONG key_index) {m_KeyIndex = key_index;}

BEGIN_COM_MAP(CKeyDefaults)
	COM_INTERFACE_ENTRY(IKeyDefaults)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}

	void FinalRelease()
	{
	}

public:
	STDMETHOD(get_Name)(BSTR* pVal);
	STDMETHOD(get_DisplayName)(BSTR* pVal);
	STDMETHOD(get_VirtualKey)(USHORT* pVal);
	STDMETHOD(get_ActionCode)(USHORT* pVal);
};
