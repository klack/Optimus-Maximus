#include "StdAfx.h"
#include "MaximusWrapper.h"

CMaximusWrapper::~CMaximusWrapper()
{

}

HRESULT CMaximusWrapper::Error(LPCSTR lpszDesc) const
{
	return AtlReportError(m_ErrorsClassID, lpszDesc);
}

HRESULT CMaximusWrapper::GetInited() const
{
	assert(m_Maximus != NULL);
	return m_Maximus != NULL ? S_OK : Error("Not inited");
}

HRESULT CMaximusWrapper::GetState() const
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		hr = m_Maximus->isConnected() ? S_OK : Error("Not connected");
	}

	return hr;	
}

HRESULT CMaximusWrapper::CheckParam(ULONG key_index) const
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		hr = key_index < MXKeyCount ? S_OK : Error("Key index out of range");
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteHBITMAP(ULONG key_index, HBITMAP hbitmap)
{
	const bool write_res = m_Maximus->writeImage(key_index, hbitmap);
	return write_res ? S_OK : Error("Error image format");
}

/*
	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{

	}

	return hr;
*/

HRESULT CMaximusWrapper::Connect()
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		m_Maximus->connect();
	}

	return hr;
}

HRESULT CMaximusWrapper::get_Connected(VARIANT_BOOL* pVal)
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		*pVal = m_Maximus->isConnected() ? VARIANT_TRUE : VARIANT_FALSE;
	}
	
	return hr;
}

HRESULT CMaximusWrapper::WriteImageFromFile(ULONG key_index, BSTR file_path)
{
	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{
		HBITMAP	hbmp = (HBITMAP)::LoadImage(NULL, COLE2T(file_path), IMAGE_BITMAP, 48, 48, LR_DEFAULTCOLOR | LR_CREATEDIBSECTION | LR_LOADFROMFILE);
		if (hbmp != NULL)
		{
			hr = WriteHBITMAP(key_index, hbmp);
			::DeleteObject(hbmp);
		}
		else
		{
			hr = AtlHresultFromLastError();
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteImageFromHbitmap(ULONG key_index, OLE_HANDLE hbitmap)
{
	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{
		hr = WriteHBITMAP(key_index, reinterpret_cast<HBITMAP>(hbitmap));
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteImageFromHbitmapAndDeleteObject(ULONG key_index, OLE_HANDLE hbitmap)
{
	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{
		HBITMAP hbmp = reinterpret_cast<HBITMAP>(hbitmap);
		hr = WriteHBITMAP(key_index, hbmp);
		::DeleteObject(hbmp);		
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteIPictureDisp(ULONG key_index, IPictureDisp* picture)
{
	CComPtr<IPictureDisp> pic = picture;

	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{
		if (picture != NULL)
		{
			CComVariant var;
			DISPPARAMS dispparamsNoArgs = {NULL, NULL, 0, 0};

			hr = picture->Invoke(DISPID_PICT_TYPE, IID_NULL, 0, DISPATCH_PROPERTYGET, &dispparamsNoArgs, &var, NULL, NULL);
			if (SUCCEEDED(hr))
			{
				if (var.iVal == PICTYPE_BITMAP)
				{
					hr = picture->Invoke(DISPID_PICT_HANDLE, IID_NULL, 0, DISPATCH_PROPERTYGET, &dispparamsNoArgs, &var, NULL, NULL);
					if (SUCCEEDED(hr))
					{
						HBITMAP hbmp = reinterpret_cast<HBITMAP>(var.byref);
						hr = WriteHBITMAP(key_index, hbmp);
						::DeleteObject(hbmp);
					}
					else
					{
						hr = Error("Can't get handle");
					}
				}
				else
				{
					hr = Error("Must be bitmap");
				}
			}
		}
		else
		{
			hr = E_POINTER;
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteKeyActionByVirtualKey(ULONG key_index, USHORT virtual_key)
{
	HRESULT hr = CheckParam(key_index);
	if (SUCCEEDED(hr))
	{
		hr = m_Maximus->writeVirtualKey(key_index, virtual_key) ? S_OK : Error("Wrong virtual key");
	}

	return hr;
}

HRESULT CMaximusWrapper::UnmountVDrive(void)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		if (m_Maximus->getDeviceInfo().VDriveLetter)
		{
			hr = m_Maximus->unmountVDrive() ? S_OK : AtlHresultFromLastError();
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::MountVDrive(void)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		if (!m_Maximus->getDeviceInfo().VDriveLetter)
		{
			hr = m_Maximus->mountVDrive() ? S_OK : Error("Can't mount");
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::UpgradeFirmwareFromFile(BSTR file_path)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		if (!m_Maximus->upgradeFirmware(COLE2T(file_path)))
		{
			DWORD le = ::GetLastError();
			hr = le != ERROR_SUCCESS ? AtlHresultFromWin32(le) : Error("Can't upgrade");
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::UpgradeFirmwareFromBuffer(BYTE* buffer, ULONG buffer_size)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		if (m_Maximus->checkFirmwareChecksum(buffer, buffer_size))
		{
			hr = m_Maximus->upgradeFirmware(buffer, buffer_size) ? S_OK : Error("Can't upgrade");
		}
		else
		{
			hr = Error("Wrong firmware");
		}
	}

	return hr;
}

HRESULT CMaximusWrapper::get_Alive(VARIANT_BOOL* pVal)
{
	HRESULT hr = GetInited();
	if (SUCCEEDED(hr))
	{
		*pVal = m_Maximus->isAlive() ? VARIANT_TRUE : VARIANT_FALSE;
	}
	
	return hr;
}

HRESULT CMaximusWrapper::get_FirmwareVersion(BSTR* pVal)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		*pVal = m_Maximus->getFirmwareVersionString().AllocSysString();
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteSleepModeDelay(ULONG delay)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		m_Maximus->writeSleepModeDelay(delay);
	}

	return hr;
}

HRESULT CMaximusWrapper::WriteBrightness(ULONG brightness, VARIANT_BOOL auto_mode)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		m_Maximus->writeBrightness(brightness, auto_mode == VARIANT_TRUE);
	}

	return hr;
}

HRESULT CMaximusWrapper::get_HIDReportByte(USHORT byte_index, BYTE* pVal)
{
	HRESULT hr = GetState();
	if (SUCCEEDED(hr))
	{
		if (byte_index < COptimusMaximus::MXInternalHIDReportSize)
		{
			*pVal = m_Maximus->getHIDReportByte(byte_index);
		}
		else
		{
			hr = Error("Byte index out of range");
		}
	}

	return hr;
}