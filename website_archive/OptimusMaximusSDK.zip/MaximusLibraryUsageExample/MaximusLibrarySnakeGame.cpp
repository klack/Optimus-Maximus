#include "stdafx.h"
#include "resource.h"
#include <iostream>
#include "..\MaximusLibrary\OptimusMaximus.h"

using namespace std;

HBITMAP CreateDIB(HDC hdc, LONG width, LONG height)
{		
	// fill bitmap info
	BITMAPINFO bmi = {0};

	bmi.bmiHeader.biSize   = sizeof(BITMAPINFOHEADER); 
	bmi.bmiHeader.biWidth  = width;
	bmi.bmiHeader.biHeight = height; 
	bmi.bmiHeader.biPlanes = 1; 
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;

	void* data = 0;
	return ::CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, &data, 0, 0);
}

HBITMAP getImage(HBITMAP combo, int idx)
{
	// returns a region from the combined image
	HDC screenDC = GetDC(NULL);
	HDC srcDC = CreateCompatibleDC(screenDC);
	HDC dstDC = CreateCompatibleDC(screenDC);
	HBITMAP res = CreateDIB(dstDC, 48, 48);
	HBITMAP oldSrc = (HBITMAP)SelectObject(srcDC, combo);
	HBITMAP oldDst = (HBITMAP)SelectObject(dstDC, res);
	BitBlt(dstDC, 0, 0, 48, 48, srcDC, 0, idx*48, SRCCOPY);
	DeleteDC(srcDC);
	DeleteDC(dstDC);
	return res;
}

HBITMAP rotateImage(HBITMAP source)
{
	HDC screenDC = GetDC(NULL);
	HDC srcDC = CreateCompatibleDC(screenDC);
	HDC dstDC = CreateCompatibleDC(screenDC);
	HBITMAP res = CreateDIB(dstDC, 48, 48);
	HBITMAP oldSrc = (HBITMAP)SelectObject(srcDC, source);
	HBITMAP oldDst = (HBITMAP)SelectObject(dstDC, res);

	for (int x=0; x<48; x++)
		for (int y=0; y<48; y++)
			BitBlt(dstDC, x, y, 1, 1, srcDC, y, 48-x, SRCCOPY);

	DeleteDC(srcDC);
	DeleteDC(dstDC);
	return res;
}

class CSnakeGame : public COptimusMaximus::IEventHandler
{
	COptimusMaximus optimus;

	int gameMap[MXKeyCount];
	int direction; // 1 - right, 2 - up, 3 - left, 4 - down
	int head;      // snake head position
	int tail;      // snake tail position
	bool quit;	   // exit flag

	HBITMAP	imgEscape,imgSnakeHead[4],imgSnakeBody,imgApple,imgStone,imgEmpty;

public:

	CSnakeGame(): direction(1), head(winVK2Maximus('S')), tail(head), quit(false)
	{
		// all game images are kept in Snake.bmp resource
		HBITMAP	combo = (HBITMAP)::LoadImage(::GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_BITMAP), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_CREATEDIBSECTION);
		imgEmpty = getImage(combo,0);
		imgEscape = getImage(combo,1);
		imgSnakeBody = getImage(combo,3);
		imgStone = getImage(combo,4);
		imgApple = getImage(combo,5);

		imgSnakeHead[3] = getImage(combo,2);
		imgSnakeHead[2] = rotateImage(imgSnakeHead[3]);
		imgSnakeHead[1] = rotateImage(imgSnakeHead[2]);
		imgSnakeHead[0] = rotateImage(imgSnakeHead[1]);

		::DeleteObject(combo);

		for(int i=0; i<MXKeyCount; i++){
			gameMap[i] = Next(i,1) < 0 ? -1 : 0;
		}

		srand(GetTickCount());

		optimus.setEventHandler(this);
		optimus.connect();
	}

	~CSnakeGame()
	{
		::DeleteObject(imgEscape);
		::DeleteObject(imgSnakeBody);
		::DeleteObject(imgApple);
		::DeleteObject(imgStone);
		::DeleteObject(imgEmpty);
		for (int i=0; i<4; i++) ::DeleteObject(imgSnakeHead[i]);

		optimus.setEventHandler(NULL);
	}

	void Play()
	{
		if (!optimus.isConnected())
		{
			cout << "Waiting for Maximus ...\n";
		}

		CONST DWORD time = ::GetTickCount();

		while(!optimus.isConnected() && ::GetTickCount() - time < 15000){
			::Sleep(100);
		}

		if (optimus.isConnected())
		{
			Game();
		}
	}

private:

	int winVK2Maximus(unsigned int winVK){
		for (int i=0; i<MXKeyCount; i++ ){
			if (g_KeyboardButtons[i].winVK == winVK){
				return i;
			}
		}
		return 0;
	}

	// return a cell which is next to currect in given direction
	int Next(int current, int direction){
		static unsigned int map[] ={ 
			'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', VK_OEM_MINUS,
		    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', VK_OEM_4,
			'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', VK_OEM_1, VK_OEM_7,
			'Z', 'X', 'C', 'V', 'B', 'N', 'M', VK_OEM_COMMA, VK_OEM_PERIOD, VK_OEM_2, VK_RSHIFT
		};
		const size_t rowLen=11;
		const size_t mapSize=sizeof(map)/sizeof(map[0]);

		for (int i=0; i<mapSize ; i++ ){
			if (g_KeyboardButtons[current].winVK == map[i]){
				switch (direction){
					case 1: i++; if ( i%rowLen == 0 ) i-=rowLen;
							break;
					case 2: i-=rowLen; if ( i<0 ) i+=mapSize;
							break;
					case 3: i--; if ( i%rowLen == 0 ) i+=rowLen;
							break;
					case 4: i+=rowLen; if ( i>=mapSize ) i-=mapSize;
							break;
				}
				return winVK2Maximus(map[i]);
			}
		}
		return -1;
	}

	void MoveHead(int direction){
		optimus.writeImage(head, imgSnakeBody);

		gameMap[head]=direction;
		head=Next(head,direction);

		optimus.writeImage(head, imgSnakeHead[direction-1]);
	}

	void MoveTail(){
		optimus.writeImage(tail, imgEmpty);

		int direction=gameMap[tail];
		gameMap[tail]=0;
		tail=Next(tail,direction);
	}

	int GetFreeCell(){
		int idx;
		while( gameMap[idx=(rand() % MXKeyCount)] != 0 && idx != head);
		return idx;
	}

	void PlaceStone(int position){
		gameMap[position]=5;
		optimus.writeImage(position, imgStone);
	}

	void PlaceApple(int position){
		gameMap[position]=6;
		optimus.writeImage(position, imgApple);
	}

	void PaintImages(){
		BYTE empty[MXKeySquare*3]={0};

		// filling keyboard with images
		optimus.writeImage(0, imgEscape);

		for	(int i=1; i	< MXKeyCount; i++){
			gameMap[i] >= 0 ? optimus.writeImage( i, imgEmpty ) : optimus.writeRGBImage( i, empty );
		}
	}

	void Game(){
		PaintImages();

		for (int i=0; i<5; i++){
			MoveHead(direction);
		}

		for (int j=0; j<5; j++){
			PlaceStone(GetFreeCell());
			PlaceApple(GetFreeCell());
		}

		Sleep(2000);

		while(optimus.isConnected() && !quit){
			MoveHead(direction);

			if (gameMap[head]!=0 && gameMap[head] !=6){
				// not empty or apple
				break;
			}

			if (gameMap[head]==0){
				MoveTail();
			} else {
				// no MoveTail, thus snake grow
				PlaceApple(GetFreeCell());
			}

			::Sleep( 800 );
		}

		cout << "Game over\n";
		Sleep(4000);
	}


	// IEventHandler interface
	virtual void OnConnect()
	{
		cout << "Maximus connected\n";
		optimus.writeZeroActionCodes();
	}

	virtual void OnDisconnect(){}

	virtual void OnKeyDown(size_t c)
	{
		if (!quit){
			switch (g_KeyboardButtons[c].winVK)
			{
			case VK_ESCAPE: quit=true;
							break;
			case VK_LEFT:	direction = direction == 4 ? 1 : direction + 1;
							optimus.writeImage(head, imgSnakeHead[direction-1]);
							break;
			case VK_RIGHT:	direction = direction == 1 ? 4 : direction - 1;
							optimus.writeImage(head, imgSnakeHead[direction-1]);
							break;
			}
		}
	}

	virtual void OnKeyUp(size_t c){}
};

int _tmain(int argc, _TCHAR* argv[])
{
	CSnakeGame().Play();

	return 0;
}
