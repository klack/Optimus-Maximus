#include "stdafx.h"
#include "resource.h"
#include <iostream>
#include "..\MaximusLibrary\OptimusMaximus.h"

using namespace std;

HBITMAP CreateDIB(HDC hdc, LONG width, LONG height)
{		
	// fill bitmap info
	BITMAPINFO bmi = {0};

	bmi.bmiHeader.biSize   = sizeof(BITMAPINFOHEADER); 
	bmi.bmiHeader.biWidth  = width;
	bmi.bmiHeader.biHeight = height; 
	bmi.bmiHeader.biPlanes = 1; 
	bmi.bmiHeader.biBitCount = 24;
	bmi.bmiHeader.biCompression = BI_RGB;

	void* data = 0;
	return ::CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, &data, 0, 0);
}

HBITMAP getImage(HBITMAP combo, int idx)
{
	// returns a region from the combined image
	HDC screenDC = GetDC(NULL);
	HDC srcDC = CreateCompatibleDC(screenDC);
	HDC dstDC = CreateCompatibleDC(screenDC);
	HBITMAP res = CreateDIB(dstDC, 48, 48);
	HBITMAP oldSrc = (HBITMAP)SelectObject(srcDC, combo);
	HBITMAP oldDst = (HBITMAP)SelectObject(dstDC, res);
	BitBlt(dstDC, 0, 0, 48, 48, srcDC, 0, idx*48, SRCCOPY);
	DeleteDC(srcDC);
	DeleteDC(dstDC);
	return res;
}


class CMemoryGame : public COptimusMaximus::IEventHandler
{
	COptimusMaximus optimus;

	int	imgIndex[MXKeyCount];	// what image is hidden under each button, -1 for buttons not in game
	int	imgToGo;				// number of buttons left unopened
	size_t lastOpened;			// -1, if nothing opened, button number otherwise

	HBITMAP	background, cancel;
	HBITMAP	images[12];			// memory images

public:

	CMemoryGame(): imgToGo(0), lastOpened(-1)
	{
		InitImages();
		PlaceImages();
		ShuffleImages();

		optimus.setEventHandler(this);
		optimus.connect();
	}

	~CMemoryGame()
	{
		::DeleteObject(background);
		::DeleteObject(cancel);

		for(int i=0; i<sizeof(images)/sizeof(images[0]); i++)
		{
			::DeleteObject(images[i]);
		}

		optimus.setEventHandler(NULL);
	}

	void Play()
	{
		if (!optimus.isConnected())
		{
			cout << "Waiting for Maximus ...\n";
		}

		CONST DWORD time = ::GetTickCount();

		do {
			::Sleep(100);
		} while	(imgToGo>0 && (optimus.isConnected() || ::GetTickCount() - time < 15000));
	}

private:
	void InitImages()
	{
		// all game images are kept in Memory.bmp resource
		HBITMAP	combo = (HBITMAP)::LoadImage(::GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_BITMAP), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR | LR_CREATEDIBSECTION);
		background = getImage(combo,0);
		cancel	= getImage(combo,1);

		for(int i=0; i<sizeof(images)/sizeof(images[0]); i++)
		{
			images[i] = getImage(combo,i+2);
		}
		::DeleteObject(combo);
	}

	void PlaceImages()
	{
		for	(int i=0; i	< MXKeyCount; i++){
			if ( g_KeyboardButtons[i].flags == mxkfHLeft || g_KeyboardButtons[i].flags == mxkfHRight || g_KeyboardButtons[i].winVK == VK_BACK){
				imgIndex[i]	= imgToGo/4;
				imgToGo++;
			} else {
				imgIndex[i]	= -1;
			}
		}
	}

	void ShuffleImages()
	{
		srand(GetTickCount());
		for	(int i=0; i<MXKeyCount*4; i++){
			int	r1 = rand()	% MXKeyCount; 
			int	r2 = rand()	% MXKeyCount;

			if (imgIndex[r1] >= 0 && imgIndex[r2] >= 0)
			{
				int	backup=imgIndex[r1];
				imgIndex[r1]=imgIndex[r2];
				imgIndex[r2]=backup;
			}
		}
	}

	void PaintImages()
	{
		BYTE empty[MXKeySquare*3]={0};

		// filling keyboard with images
		optimus.writeImage(	0, cancel );

		for	(int i=1; i	< MXKeyCount; i++){
			imgIndex[i] >= 0 ? optimus.writeImage( i, background ) : optimus.writeRGBImage( i, empty );
		}

		optimus.writeSleepModeDelay(COptimusMaximus::MXSleepModeDelayInfinite);
	}

	// IEventHandler interface
	virtual void OnConnect()
	{
		cout << "Maximus connected\n";
		optimus.writeZeroActionCodes();
		PaintImages();
	}

	virtual void OnDisconnect(){}

	virtual void OnKeyDown(size_t c)
	{
		if (c == 0){
			imgToGo=0;
		}

		if (imgIndex[c]<0 || c == lastOpened){
			return;
		}

		optimus.writeImage(c, images[imgIndex[c]]);

		if (lastOpened>=0){
			if(imgIndex[lastOpened]	== imgIndex[c]){
				imgIndex[lastOpened] = imgIndex[c] = -1;
				imgToGo-=2;
				c=-1;
			} else {
				optimus.writeImage(lastOpened, background);
			}
		}
		lastOpened=c;
	}

	virtual void OnKeyUp(size_t c){}
};

int _tmain(int argc, _TCHAR* argv[])
{
	CMemoryGame().Play();

	return 0;
}
