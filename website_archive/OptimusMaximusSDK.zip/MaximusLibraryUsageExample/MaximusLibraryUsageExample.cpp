#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include "..\MaximusLibrary\OptimusMaximus.h"

using namespace std;

struct CMyEventHandler : public COptimusMaximus::IEventHandler
{
	virtual void OnConnect()
	{
		cout << "Maximus Connected\n";
	}

	virtual void OnDisconnect()			
	{
		cout << "Maximus Disconected\n";
	}

	virtual void OnKeyDown(size_t key_id)
	{
		cout << "Key number " << setw(3) << (unsigned int)key_id << " pressed\n";
	}

	virtual void OnKeyUp(size_t key_id)
	{
		cout << "Key number " << setw(3) << (unsigned int)key_id << " released\n";
	}
};

CMyEventHandler g_EventHandler;

int _tmain(int argc, _TCHAR* argv[])
{
	COptimusMaximus optimus;
	optimus.setEventHandler(&g_EventHandler);

	optimus.connect();
	if (optimus.isConnected())
	{
		//optimus.unmountVDrive();

		//Just to ensure the keyboard is not in sleep mode
		optimus.writeSleepModeDelay(180);

		for (size_t ii = 0; ii < 420; ++ii)
		{
			DWORD buff[48*48];
			fill(buff, buff + sizeof(buff)/sizeof(DWORD), rand() | (rand() << 15));

			for (size_t ii = 0; ii < MXKeyCount; ++ii)
			{
				optimus.writeRGBAImage(ii, (BYTE*)buff);
			}

			::Sleep(100);
		}
	}
	else
	{
		cout << "Connection failed\n";
		::Sleep(7000);
	}

	return 0;
}

