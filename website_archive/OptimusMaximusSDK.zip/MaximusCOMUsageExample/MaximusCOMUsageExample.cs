using System;
using System.Collections.Generic;
using System.Text;

using System.Drawing;
using System.Drawing.Imaging;

using MaximusCOMLib;

namespace MaximusCOMTest
{
    class MaximusCOMUsageExample
    {
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

        static void Maximus_Connect()
        {
            System.Console.WriteLine("Connected");
        }

        static void Maximus_Disconnect()
        {
            System.Console.WriteLine("Disconnected");
        }

        static void Main(string[] args)
        {
            try
            {
                oMaximus.OnConnect += Maximus_Connect;
                oMaximus.OnDisconnect += Maximus_Disconnect;

                oMaximus.Connect();
                if (oMaximus.Connected)
                {
                    //oMaximus.UnmountVDrive();
                    oMaximus.WriteSleepModeDelay(180);

                    System.Console.WriteLine((char)oMaximus.DeviceInfo.VDriveLetter);
                    System.Console.WriteLine(oMaximus.DeviceInfo.VDriveVolumeName);

                    Bitmap bmp = new Bitmap((int)MaximusConstants.KeyWidth, (int)MaximusConstants.KeyHeight, PixelFormat.Format24bppRgb);
                    Graphics g = Graphics.FromImage(bmp);

                    Random r = new Random();

                    for (int ii = 0; ii < 420; ++ii)
                    {
                        g.FillRectangle(new SolidBrush(Color.FromArgb(255, (byte)r.Next(), (byte)r.Next(), (byte)r.Next())),
                             0, 0, (int)MaximusConstants.KeyWidth, (int)MaximusConstants.KeyHeight);

                        IntPtr hbitmap = bmp.GetHbitmap();

                        foreach (Key key in oMaximus.Keys)                      
                        {                            
                            key.WriteImageFromHbitmap((int)hbitmap);
                        }

                        DeleteObject(hbitmap);

                        System.Threading.Thread.Sleep(100);
                    }
                    g.Dispose();

                    oMaximus = null; //Deleting object earlie to ensure internal library thread will be finished 
                    GC.Collect();
                }
                else 
                {
                    System.Console.WriteLine("Connection failed");
                    System.Threading.Thread.Sleep(7000);
                }
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e);
                System.Threading.Thread.Sleep(7000);
            }            
        }

        static MaximusCOMLib.Keyboard oMaximus = new MaximusCOMLib.Keyboard();
    }    
}

