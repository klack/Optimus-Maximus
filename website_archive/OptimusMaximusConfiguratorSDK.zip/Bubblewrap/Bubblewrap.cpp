#include "stdafx.h"

//Optimus SDK interfaces
#include "iMXPlugin.h"

//STL includes
#include <set>
#include <string>
#include <algorithm>

//We using gdiplus for loading PNG images
#include <gdiplus.h>
#pragma comment(lib, "GdiPlus.lib")
using namespace Gdiplus;

#pragma comment(lib, "Winmm.lib") //4PlaySound

using namespace std;

/*
This class is utilitarian purpose. It determines the path to the directory with a plugin. 
But its primary function: storing the list of active plugin instances for their co-operation.
*/
class CBubblewrapPluginModule
{
private:
	typedef class CBubblewrapViewInstance* instance_t;

	CBubblewrapPluginModule():m_hInstance(NULL){}

public:
	void setHInstance(HINSTANCE hInstance){m_hInstance = hInstance;}
	HINSTANCE getHInstance(){return m_hInstance;}

	//Win API wrappers
	const std::wstring& getModulePath() const
	{
		assert(m_hInstance);
		if (m_hInstance != NULL && m_ModulePath.empty())
		{
			TCHAR file_name[MAX_PATH] = {0};
			::GetModuleFileName(m_hInstance, file_name, MAX_PATH);
			m_ModulePath = file_name;
		}

		return m_ModulePath;
	}

	const std::wstring& getModuleDir() const
	{
		if (m_ModuleDir.empty())
		{
			m_ModuleDir = getModulePath();
			const std::wstring::size_type find_res = m_ModuleDir.rfind(L'\\');
			if (find_res != std::wstring::npos)
			{
				m_ModuleDir.erase(find_res + 1);				
			}
		}

		return m_ModuleDir;
	}

	static CBubblewrapPluginModule& getInstance()
	{
		static CBubblewrapPluginModule instance;
		return instance;
	}

private:
	HINSTANCE m_hInstance;

	mutable std::wstring m_ModulePath;
	mutable std::wstring m_ModuleDir;

public:
	//Working with list of active plugin instances
	void registerInstance(instance_t val)
	{
		m_Instances.insert(val);
	}

	void unregisterInstance(instance_t val)
	{
		m_Instances.erase(val);
		coordinate();
	}

	void coordinate();

private:
	typedef std::set<instance_t> store_t;

	store_t m_Instances;
};

class CBubblewrapViewInstance : public CMXViewPluginInstance
{
public:
	CBubblewrapViewInstance(IMXViewPluginContext* context):CMXViewPluginInstance(context)
	{
		m_Popped = false;
	}

private:
	//IMXViewPluginInstance
	virtual void __stdcall Show()
	{
		Recall();
		CBubblewrapPluginModule::getInstance().registerInstance(this);
	}

	virtual void __stdcall Hide()
	{		
		CBubblewrapPluginModule::getInstance().unregisterInstance(this);
	}

private:
	void drawImage(PCTSTR file_name)
	{
		Image image((CBubblewrapPluginModule::getInstance().getModuleDir() + file_name).c_str());
		
		HDC hdc = getContext()->GetDC(); //Get a graphical context for drawing
		Graphics g(hdc);
		g.DrawImage(&image, 0, 0, 48, 48);

		getContext()->OnUpdate(); //Notify on changing image
	}

public:
	//This method will be invoked template CDefaultViewAction when pressing the button
	void DoDefaultAction()
	{
		if (!m_Popped)
		{
			::PlaySound((CBubblewrapPluginModule::getInstance().getModuleDir() + L"sound.wav").c_str(), NULL, SND_ASYNC);
			drawImage(L"popped.png");

			m_Popped = true;			
		}
		else
		{
			CBubblewrapPluginModule::getInstance().coordinate();
		}
	}

	void Recall()
	{
		drawImage(L"virgine.png");
		m_Popped = false;
	}

	bool isIntact() const
	{
		return !m_Popped;
	}

private:
	bool m_Popped;
};

void CBubblewrapPluginModule::coordinate()
{
	if (find_if(m_Instances.begin(), m_Instances.end(), mem_fun(&CBubblewrapViewInstance::isIntact)) == m_Instances.end())
	{
		for_each(m_Instances.begin(), m_Instances.end(), mem_fun(&CBubblewrapViewInstance::Recall));
	}
}

//Export function for creating view instance
//id and other static information about plugin declared in Info.plist
extern "C" __declspec(dllexport) IMXViewPluginInstance* createView(LPCWSTR id, IMXViewPluginContext* context)
{
	return new CBubblewrapViewInstance(context);
}

class CDefaultViewAction : public CMXActionPluginInstance
{
public:
	CDefaultViewAction(IMXActionPluginContext* context):CMXActionPluginInstance(context){}

private:
	//CMXActionPluginInstance
	virtual void __stdcall KeyDown()
	{		
		IMXViewPluginInstance* corresponding_view = getContext()->GetView();
		if (corresponding_view != NULL)
		{
			static_cast<CBubblewrapViewInstance*>(corresponding_view)->DoDefaultAction();
		}
	}

	virtual void __stdcall KeyUp()
	{		
	}
};

//Export function for creating action instance
//id and other static information about plugin declared in Info.plist
extern "C" __declspec(dllexport) IMXActionPluginInstance* createAction(LPCWSTR id, IMXActionPluginContext* context)
{
	return new CDefaultViewAction(context);
}

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	//Saving hInstance for subsequent determination dll module path
	CBubblewrapPluginModule::getInstance().setHInstance(hInstance);

	return 1;   // ok
}
