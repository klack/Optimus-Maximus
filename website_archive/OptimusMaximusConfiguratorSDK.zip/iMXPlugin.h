#ifndef MAXIMUS_PLUGINS_INTERFACE
#define MAXIMUS_PLUGINS_INTERFACE

#define MX_MAX_INFO_STRING 512

/* ************************************ plugin context ************************************ */

// There are view, action and condition plug-ins, each is a corresponding plugin context class, which provides specific interface to Configurator.
// Plugin context is passed by Configurator on plugin creation. Basic class allows to save and restore plugin properties.

class IMXPluginContext
{
public:
	virtual void __stdcall StoreProperty(LPCWSTR id, LPCWSTR value)  = 0;
	virtual BOOL __stdcall RestoreProperty(LPCWSTR id, LPWSTR value) = 0; // FALSE if no property with this id

	virtual void __stdcall GetContainerID(LPWSTR value) = 0; // returns GUID of layer or group, where plugin is located
	virtual void __stdcall GetContainerName(LPWSTR value) = 0; // returns name of layer or group, where plugin is located

	virtual void __stdcall Free() = 0; // called from CMXPluginInstance destructor
};

// Plugin context for view plugin allows to send an image to Configurator
class IMXViewPluginContext : public IMXPluginContext
{
public:
	virtual class IMXActionPluginInstance* __stdcall GetAction() = 0; // NULL if action and view from different plugins

	virtual UINT __stdcall GetButtonRow() = 0; // Returns plugin position on the keyboard 
	virtual UINT __stdcall GetButtonCol() = 0;
	virtual UINT __stdcall GetButtonX() = 0;
	virtual UINT __stdcall GetButtonY() = 0;

	virtual HDC  __stdcall GetDC() = 0; // Can be called only after IMXViewPluginInstance::Show, returns HDC where plugin should paint itselt 
	virtual void __stdcall OnUpdate() = 0;	// Should be called each time after plugin paints itself on Device Context
};

class IMXActionPluginContext : public IMXPluginContext
{
public:
	virtual class IMXViewPluginInstance* __stdcall GetView() = 0; // NULL if action and view from different plugins
};

class IMXConditionPluginContext : public IMXPluginContext
{
public:
	virtual void __stdcall OnChangeState(BOOL new_state) = 0; // to report condition change, initial state can be set from constructor
};

/* ************************************ plugin ************************************ */

class IMXPluginGUIController
{
public:
	virtual HWND __stdcall ShowUI(HWND parent) = 0; // Shows plugin preferences 
	virtual void __stdcall HideUI() = 0;		// Hide plugin preferences 

	/*
		Will be called only if the SupportsFilesDragDrop key is present in plist description.
			<key>SupportsFilesDragDrop</key>
			<true />
	*/
	virtual BOOL __stdcall OnDropFile(LPCWSTR lpszfileName) = 0; // Returns true if will accept more files
};

class IMXPluginInstance
{
public:
	/*
		Will be called only if the HasUI key is present in plist description.
			<key>HasUI</key>
			<true />            
		otherwise fill Description key
			<key>Description</key>
			<string>Plugin description here</string>
	*/
	virtual IMXPluginGUIController* __stdcall getGUIController() = 0;

	virtual void __stdcall Free() = 0; // implemented in CMXPluginInstance, no need to override
};

class IMXViewPluginInstance : public IMXPluginInstance
{
public:
	typedef IMXViewPluginContext context_t;

public:
	/*
		View plugin work cycle starts when Configurator calls Show(), signalling that plugin is visible and should paint itself
		Paint routine should start with getContext()->GetDC(), followed by paint code, then end with getContext()->OnUpdate().
		When plugin becomes invisible, Configurator calls Hide()
	*/
	virtual void __stdcall Show() = 0;
	virtual void __stdcall Hide() = 0;
};

class IMXActionPluginInstance : public IMXPluginInstance
{
public:
	typedef IMXActionPluginContext context_t;

public:
	virtual void __stdcall KeyDown() = 0; // There is no auto-repeat, just one keydown event for each key press
	virtual void __stdcall KeyUp() = 0;
};


class IMXConditionPluginInstance : public IMXPluginInstance
{
public:
	typedef IMXConditionPluginContext context_t;
};

/* ******************************** plugin with context template ************************** */

template <class I>
class CMXPluginInstance : public I
{
public:
	CMXPluginInstance(typename I::context_t* context):m_Context(context){}	
	virtual ~CMXPluginInstance(){m_Context->Free();}

protected:
	typename I::context_t* getContext(){return m_Context;}

	virtual void __stdcall Free() {delete this;}
	virtual IMXPluginGUIController* __stdcall getGUIController() {return NULL;}

private:
	typename I::context_t* m_Context;
};


/* ************************************ exported functions ************************************ */

typedef CMXPluginInstance<IMXViewPluginInstance>      CMXViewPluginInstance;
typedef CMXPluginInstance<IMXActionPluginInstance>    CMXActionPluginInstance;
typedef CMXPluginInstance<IMXConditionPluginInstance> CMXConditionPluginInstance;

/*

// Each dll can contain many plugins. Configurator reads Info.plist where plugin id and other static information is declared.
// Below are export functions Confirurator calls to create view, action and condition plugin instances

extern "C" __declspec(dllexport) IMXViewPluginInstance* createView(LPCWSTR id, IMXViewPluginContext*)
{
}

extern "C" __declspec(dllexport) IMXActionPluginInstance* createAction(LPCWSTR id, IMXActionPluginContext*)
{
}

extern "C" __declspec(dllexport) IMXConditionPluginInstance* createCondition(LPCWSTR id, IMXConditionPluginContext*)
{
}
*/

#endif //MAXIMUS_PLUGINS_INTERFACE