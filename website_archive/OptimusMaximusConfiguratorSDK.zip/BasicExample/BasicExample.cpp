#include "stdafx.h"

//Optimus SDK interfaces
#include "iMXPlugin.h"

#include "RandomConditionPropertiesFrame.h"

#include <time.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

class CBasicExampleViewInstance : public CMXViewPluginInstance
{
public:
	CBasicExampleViewInstance(IMXViewPluginContext* context):CMXViewPluginInstance(context)
	{
	}

private:
	//IMXViewPluginInstance
	virtual void __stdcall Show()
	{
		HDC hdc = getContext()->GetDC();

		RECT rect = {0, 0, 48, 48};
		::SetBkColor(hdc, RGB(0, 255, 0));
		::ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rect, NULL, 0, NULL); 

		getContext()->OnUpdate();
	}

	virtual void __stdcall Hide()
	{		
	}
};

extern "C" __declspec(dllexport) IMXViewPluginInstance* createView(LPCWSTR id, IMXViewPluginContext* context)
{
	return new CBasicExampleViewInstance(context);
}

class CBasicExampleActionInstance : public CMXActionPluginInstance
{
public:
	CBasicExampleActionInstance(IMXActionPluginContext* context, UINT style):CMXActionPluginInstance(context), m_BeepStyle(style)
	{
	}
	
private:
	//IMXActionPluginInstance
	virtual void __stdcall KeyDown()
	{
		::MessageBeep(m_BeepStyle);
	}

	virtual void __stdcall KeyUp()
	{
	}

private:
	UINT m_BeepStyle;
};

extern "C" __declspec(dllexport) IMXActionPluginInstance* createAction(LPCWSTR id, IMXActionPluginContext* context)
{
	if (wcsstr(id, L"first") == id)
	{
		return new CBasicExampleActionInstance(context, MB_ICONQUESTION);
	}
	else
	{
		return new CBasicExampleActionInstance(context, MB_OK);
	}
}

class CBasicExampleConditionInstance : public CMXConditionPluginInstance, public IMXPluginGUIController, public IRandomConditionProps
{
public:
	CBasicExampleConditionInstance(IMXConditionPluginContext* context):CMXConditionPluginInstance(context)
	{
		WCHAR buff[MX_MAX_INFO_STRING] = {0};

		if (getContext()->RestoreProperty(L"Threshold", buff))
		{
			m_Params.m_Threshold = _ttoi(buff);
		}

		srand((unsigned)time(NULL));

		m_Timer = ::timeSetEvent(7000, 7000, &CBasicExampleConditionInstance::TimerProc, (DWORD_PTR)this, 
			TIME_PERIODIC | TIME_CALLBACK_FUNCTION | TIME_KILL_SYNCHRONOUS);
	}

	~CBasicExampleConditionInstance()
	{
		::timeKillEvent(m_Timer);
	}

public:
	//IRandomConditionProps
	virtual void setVal(int val)
	{
		m_Params.m_Threshold = val;

		WCHAR buff[MX_MAX_INFO_STRING] = {0};
		_itot(val, buff, 10);

		getContext()->StoreProperty(L"Threshold", buff);
	};

	//IMXPluginInstance
	virtual IMXPluginGUIController* __stdcall getGUIController(){return this;}
	
	//IMXGUIPluginGUIController
	virtual HWND __stdcall ShowUI(HWND parent)
	{
		m_Frame.SetView(this);		
		m_Frame.Create(CRandomConditionPropertiesFrame::IDD, CWnd::FromHandle(parent));

		m_Frame.SetParams(m_Params);
		return m_Frame.GetSafeHwnd();
	}

	virtual void __stdcall HideUI()
	{
		m_Frame.DestroyWindow();
	}

	virtual BOOL __stdcall OnDropFile(LPCWSTR file_name){return FALSE;}

private:
	CRandomConditionPropertiesFrame m_Frame;
	TextModePluginViewParams m_Params;

private:
	void dice()
	{
		getContext()->OnChangeState(rand()%TextModePluginViewParams::MaxValue < m_Params.m_Threshold ? TRUE : FALSE);
	}

private:
	static VOID CALLBACK TimerProc(UINT uTimerID, UINT uMsg, DWORD_PTR dwUser, DWORD_PTR dw1, DWORD_PTR dw2)
	{
		reinterpret_cast<CBasicExampleConditionInstance*>(dwUser)->dice();
	}

private:
	MMRESULT m_Timer;
};

extern "C" __declspec(dllexport) IMXConditionPluginInstance* createCondition(LPCWSTR id, IMXConditionPluginContext* context)
{
	return new CBasicExampleConditionInstance(context);
}
