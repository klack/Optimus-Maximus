// RandomConditionPropertiesFrame.cpp : implementation file
//

#include "stdafx.h"
#include "RandomConditionPropertiesFrame.h"

// CRandomConditionPropertiesFrame dialog

IMPLEMENT_DYNAMIC(CRandomConditionPropertiesFrame, CRandomConditionPropertiesFrame::base_t)

CRandomConditionPropertiesFrame::CRandomConditionPropertiesFrame(CWnd* pParent /*=NULL*/)
	: base_t(CRandomConditionPropertiesFrame::IDD, pParent), m_View(NULL)
{
}

CRandomConditionPropertiesFrame::~CRandomConditionPropertiesFrame()
{
}

void CRandomConditionPropertiesFrame::DoDataExchange(CDataExchange* pDX)
{
	base_t::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDER, m_Slider);
}

BEGIN_MESSAGE_MAP(CRandomConditionPropertiesFrame, CRandomConditionPropertiesFrame::base_t)
	ON_WM_HSCROLL()
END_MESSAGE_MAP()

// CRandomConditionPropertiesFrame message handlers

BOOL CRandomConditionPropertiesFrame::OnInitDialog()
{
	base_t::OnInitDialog();

	m_Slider.SetRange(1, TextModePluginViewParams::MaxValue);

	return FALSE;
}

void CRandomConditionPropertiesFrame::SetParams(TextModePluginViewParams& params)
{
	m_Slider.SetPos(params.m_Threshold);
}

void CRandomConditionPropertiesFrame::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if (m_View)
	{
		m_View->setVal(m_Slider.GetPos());
	}
}

