#pragma once

// CRandomConditionPropertiesFrame dialog

#include "resource.h"
#include "afxwin.h"

#include <string>
#include <vector>
#include "afxcmn.h"

struct TextModePluginViewParams
{
  static const int MaxValue = 42;

  TextModePluginViewParams()
  {
    m_Threshold = MaxValue/2;
  }

  int m_Threshold;
};

class IRandomConditionProps
{
public:
  virtual void setVal(int) = 0;
};

class CRandomConditionPropertiesFrame : public CDialog
{
  DECLARE_DYNAMIC(CRandomConditionPropertiesFrame)

private:
  typedef CDialog base_t;

public:
  CRandomConditionPropertiesFrame(CWnd* pParent = NULL);   // standard constructor
  virtual ~CRandomConditionPropertiesFrame();

  void SetView(IRandomConditionProps* view){m_View = view;}
  void SetParams(TextModePluginViewParams&);

private:
  IRandomConditionProps* m_View;

  virtual void OnOK(){}
  virtual void OnCancel(){}

public:
// Dialog Data
  enum { IDD = IDD_RANDOM_PROPS };

protected:
  virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
  BOOL OnInitDialog();

  DECLARE_MESSAGE_MAP()

public:
  void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

public:
  CSliderCtrl m_Slider;
};
