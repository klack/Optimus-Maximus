iMXPlugin.h - plugin interface description for Optimus Maximus Configurator version 0.0.17.

ConfiguratorSDK.sln - Visual Studio 2005 solution.

BasicExample - plugin with preferences example.
Bubblewrap - bubble wrap game plugin example.

Release\Plugins - compiled binaries (Visual C++ runtime required).

Compiled plugins should be placed into C:\Program Files\Optimus Maximus Configurator\plugins\.
Unless you are familiar with C++ runtime, plugin dlls should be compiled as VS2005 release.

Each plugin example has Data directory, which contains plugin resources and libraries and 
Info.plist with plugin name and description. Plugin id is used as a key to store user settings.
See the following example for View plugin Info.plist and naming convention:

...
<plist version="1.0">
    <dict>
        <key>[plugin id].[author nickname]</key>
        <dict>
            <key>DisplayName</key>
            <string>[plugin submenu name]</string>
            <key>Views</key>
            <dict>
                <key>[plugin id].view</key>
                <dict>
                    <key>DisplayName</key>
                    <string>[view plugin name]</string>
                </dict>
            </dict>
	    ...
        </dict>
    </dict>
</plist>

For more information on plist format see
http://developer.apple.com/documentation/Cocoa/Conceptual/PropertyLists/
